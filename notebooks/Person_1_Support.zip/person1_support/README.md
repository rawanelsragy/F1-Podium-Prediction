# Completed Person 1 deliverables

This package updates `notebooks/part1completed.ipynb` from the `rawan` branch at commit `adac1ace4f88b713206473f1dafe22ebbc24065c`. This update is for the `rawan` branch; it does not merge into `main`.

## Files

- `../part1completed.ipynb`: executed notebook with all Person 1 cleaning, EDA, quality checks and Q1.
- `cleaning.py`: reusable cleaning functions; accepts a dictionary of the 14 raw pandas DataFrames and returns cleaned copies.
- `figures_and_results/`: all ten figures, conversion audits, Q1 result tables and written interpretation.
- `verification.md`: validation results.
- `requirements.txt`: Python dependencies.

## What changed

1. Completed nullable numeric typing in results, sprint results and driver numbers. Added fastest-lap seconds and elapsed race seconds from canonical milliseconds. Original mixed elapsed/gap time text is retained and not confused with absolute time. Added zero-loss parsing audits for the new conversions and the earlier dates, qualifying laps, lap times and pit-stop durations.
2. Added `races.year -> seasons.year` to foreign-key validation, and assertions that stop execution on key failures.
3. Exported the first five cleaning plots. All ten figures are now saved, with a manifest.
4. Updated the reusable cleaner to include the new typing step and verified that it still matches the notebook output. Replaced the old hardcoded duplicate-group count with a calculated count.

Current-race outcomes and elapsed/fastest-lap timings remain post-race information and must not be used as current-race model features.

## Run

On Kaggle, attach the dataset `rohanrao/formula-1-world-championship-1950-2020` and run all cells; the existing Kaggle data path remains the default. Install dependencies from requirements.txt when running elsewhere. For a local run, set `F1_DATA_DIR` to the folder containing the 14 CSVs and optionally set `F1_OUTPUT_DIR` to a dedicated output folder before launching Jupyter. Then run every cell in order. No raw CSV is written by the notebook.

To reuse the cleaner:

```python
from pathlib import Path
import pandas as pd
from cleaning import clean_tables
raw = {p.stem: pd.read_csv(p) for p in Path("data/raw").glob("*.csv")}
cleaned = clean_tables(raw)
```

## Scope

This package completes the Person 1 scope plus Q1. The full team's modeling, Q2/Q3, experiments, explainability, inference, final analytical report and submission are outside this package. The plots and Q1 interpretation are ready for inclusion in that report.
