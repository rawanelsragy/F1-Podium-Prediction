### Q1 — Computed answer and interpretation
- **Starting grid, Before 2014:** highest observed conversion: Circuit de Nevers Magny-Cours: 80.6% (29/36).
- **Starting grid, 2014 onward:** highest observed conversion: Suzuka Circuit: 88.9% (16/18).
- **Starting grid, rank comparison:** 14 of 16 common eligible circuits change rank (ties use competition ranking).
  Largest absolute conversion change among those circuits: Circuit de Monaco, +36.2 percentage points.
- **Qualifying, Before 2014:** highest observed conversion: Circuit de Nevers Magny-Cours: 88.9% (16/18).
- **Qualifying, 2014 onward:** highest observed conversion: Suzuka Circuit: 88.9% (16/18).
- **Qualifying, rank comparison:** 13 of 14 common eligible circuits change rank (ties use competition ranking).
  Largest absolute conversion change among those circuits: Circuit de Spa-Francorchamps, +27.7 percentage points.

**Interpretation and limits:** these are historical associations, not causal circuit effects. Driver and constructor strength, era composition, race counts and missing qualifying coverage differ. Wilson intervals are approximate: the two front-row drivers share a race, so observations are not fully independent. Sparse samples and overlapping intervals limit confidence in exact rankings. Qualifying and grid must remain distinct; neither measure's missing values are substituted with the other. The before-2014 comparison covers much more history, and the post-2014 sample ends at the dataset's latest season.

**Pre-race cutoff:** Q1 outcomes are used only as historical analysis labels. For later prediction, derive any circuit conversion feature from prior races only; do not merge this full-history outcome aggregate into every modeling row.