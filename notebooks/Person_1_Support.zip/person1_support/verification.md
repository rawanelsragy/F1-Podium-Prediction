# Verification of completed Person 1 notebook

- Fresh Jupyter execution: all 33 code cells passed, in order, with outputs retained.
- Execution used the downloaded 14-table Kaggle dataset; only the dataset/output directories were supplied through environment variables.
- Raw CSV SHA-256 hashes were unchanged after execution.
- Raw DataFrames were independently confirmed unchanged by the standalone reusable cleaner.
- Results records: 26,759 before, 26,668 after; zero duplicate `(raceId, driverId)` pairs remain.
- All 14 primary-key audits and 23 foreign-key audits pass, including the added season relationship.
- Parsing failures: 0 across 13 added numeric/timing checks and 0 across 12 date/duration checks.
- Reusable cleaner: validated independently on all 14 tables; notebook also checks equality against the inline pipeline.
- Figures: 10 PNGs exported and listed in `figures_and_results/plot_manifest.csv`.
- Q1 completed with separate qualifying and starting-grid definitions, pre/post-2014 comparison, uncertainty intervals, minimum-sample sensitivity and written interpretation. Reproduces the prior audit results.
- This update targets `rawan` only; no merge into `main` is included.

The kernel printed a macOS process-inspection permission warning during shutdown, after all cells had completed successfully; the runner exited successfully and all outputs were saved.
