"""Reusable Person 1 cleaning helpers. Raw input DataFrames are preserved."""
import numpy as np
import pandas as pd

def time_to_seconds(value):
    if pd.isna(value):
        return np.nan

    parts = str(value).split(":")

    try:
        if len(parts) == 2:
            minutes, seconds = parts
            return float(minutes) * 60 + float(seconds)

        elif len(parts) == 3:
            hours, minutes, seconds = parts
            return (
                float(hours) * 3600
                + float(minutes) * 60
                + float(seconds)
            )

        else:
            return float(value)

    except ValueError:
        return np.nan

# Columns with missing sentinels can otherwise remain text after replacement.
INTEGER_COLUMNS = {
    "drivers": ["number"],
    "results": ["number", "position", "milliseconds", "fastestLap", "rank"],
    "sprint_results": ["number", "position", "milliseconds", "fastestLap"],
}
FLOAT_COLUMNS = {"results": ["fastestLapSpeed"]}

def apply_semantic_types(tables):
    """Complete typing in an already-copied table dictionary; return parse audit."""
    audit = []
    def record(table, column, source, converted):
        bad = source.notna() & converted.isna()
        audit.append({"table": table, "column": column,
                      "nonmissing_input": int(source.notna().sum()),
                      "parse_failures": int(bad.sum()),
                      "examples": source.loc[bad].astype(str).head(3).tolist()})
        if bad.any():
            raise ValueError(f"Unexpected parse failures in {table}.{column}: {audit[-1]['examples']}")
    for table, columns in INTEGER_COLUMNS.items():
        for column in columns:
            if column not in tables[table]:
                continue
            source = tables[table][column]
            converted = pd.to_numeric(source, errors="coerce")
            record(table, column, source, converted)
            tables[table][column] = converted.astype("Int64")
    for table, columns in FLOAT_COLUMNS.items():
        for column in columns:
            source = tables[table][column]
            converted = pd.to_numeric(source, errors="coerce")
            record(table, column, source, converted)
            tables[table][column] = converted.astype("Float64")
    for table in ["results", "sprint_results"]:
        source = tables[table]["fastestLapTime"]
        converted = source.apply(time_to_seconds)
        record(table, "fastestLapTime_seconds", source, converted)
        tables[table]["fastestLapTime_seconds"] = converted.astype("Float64")
        # results.time mixes winner elapsed times and relative gaps (e.g. +5.123).
        # The canonical milliseconds field already records elapsed race time.
        # Keep the original text; do not interpret a gap as elapsed race time.
        tables[table]["elapsed_time_seconds"] = tables[table]["milliseconds"].astype("Float64") / 1000
    return pd.DataFrame(audit)


DATE_COLUMNS = {'drivers': ['dob'], 'races': ['date', 'fp1_date', 'fp2_date', 'fp3_date', 'quali_date', 'sprint_date']}
DURATION_COLUMNS = {'qualifying': {'q1': 'q1_seconds', 'q2': 'q2_seconds', 'q3': 'q3_seconds'}, 'lap_times': {'time': 'time_seconds'}, 'pit_stops': {'duration': 'duration_seconds'}}

def clean_tables(raw_tables):
    clean = {name: df.copy(deep=True) for name, df in raw_tables.items()}
    for df in clean.values():
        df.replace('\\N', np.nan, inplace=True)
    for name, columns in DATE_COLUMNS.items():
        for col in columns:
            if col in clean[name]:
                clean[name][col] = pd.to_datetime(clean[name][col], errors='coerce')
    for name, mappings in DURATION_COLUMNS.items():
        for original_col, new_col in mappings.items():
            clean[name][new_col] = clean[name][original_col].apply(time_to_seconds)
    apply_semantic_types(clean)
    results = clean['results'].copy()
    results['valid_grid'] = results['grid'] > 0
    clean['results'] = results.sort_values(['raceId', 'driverId', 'valid_grid', 'grid', 'resultId'], ascending=[True, True, False, True, True]).drop_duplicates(['raceId', 'driverId'], keep='first').drop(columns='valid_grid')
    return clean
