# Run after completed Person 1, Person 2 and Person 3 sections.

PERSON4_OUTPUT_DIR = Path(os.environ.get("F1_PERSON4_OUTPUT_DIR", "/kaggle/working/person4_outputs"))
PERSON4_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
person4_input_fingerprints = {name: pd.util.hash_pandas_object(frame, index=True).sum()
                              for name, frame in tables_clean.items()}
person4_model_fingerprint = pd.util.hash_pandas_object(modeling_table, index=True).sum()
# Save this section's original plots without rewriting Zeina's plot functions.
person4_plot_files = []
def person4_show(*args, _original_show=plt.show, **kwargs):
    for figure_number in plt.get_fignums():
        figure = plt.figure(figure_number)
        if any("SHAP" in axis.get_title() for axis in figure.axes):
            figure.set_size_inches(max(16, figure.get_figwidth()), figure.get_figheight())
            figure.tight_layout()
        filename = f"person4_figure_{len(person4_plot_files) + 1:02d}.png"
        figure.savefig(PERSON4_OUTPUT_DIR / filename, dpi=160, bbox_inches="tight")
        person4_plot_files.append(filename)
    result = _original_show(*args, **kwargs)
    plt.close("all")
    return result
plt.show = person4_show


import os, random, warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    roc_auc_score, average_precision_score, f1_score,
    precision_recall_curve, roc_curve, confusion_matrix,
    classification_report
)

import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, Dropout, Input
from tensorflow.keras.callbacks import EarlyStopping

# Keep warnings visible during verification.

SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

# Small fixed thread pools keep Run All usable in CPU and constrained environments.
tf.config.threading.set_intra_op_parallelism_threads(2)
tf.config.threading.set_inter_op_parallelism_threads(2)
print("TensorFlow:", tf.__version__)

try:
    import shap
    SHAP_AVAILABLE = True
    print("SHAP:", shap.__version__)
except Exception as e:
    SHAP_AVAILABLE = False
    raise ImportError("SHAP is required for this section; install shap and rerun.") from e

df = modeling_table.copy()
DATA_READY = True

print("Loaded modeling table from Person 2")
print("Shape:", df.shape)
display(df.head())

target_col = "podium"
year_col = "year"

required = {target_col, year_col}
missing = required - set(df.columns)

if missing:
    raise ValueError(f"Missing required columns: {missing}")

if not df[target_col].dropna().isin([0, 1]).all():
    raise ValueError("podium target must be binary 0/1")

print("Target:", target_col)
print("Year column:", year_col)
print("Podium prevalence:", round(df[target_col].mean(), 4))

if {"raceId", "driverId"}.issubset(df.columns):
    duplicate_pairs = df.duplicated(["raceId", "driverId"]).sum()
    print("Duplicate (raceId, driverId) rows:", duplicate_pairs)
assert {"raceId", "driverId", target_col, year_col}.issubset(df.columns)
assert df[["raceId", "driverId", target_col, year_col]].notna().all().all()
assert duplicate_pairs == 0


PERSON2_ALLOWED_FEATURES = [
    "year",
    "circuitId",
    "grid_position",
    "qualifying_position",
    "is_home_race",
    "driver_prior_starts",
    "driver_prior_podium_rate",
    "driver_prior_mean_finish",
    "constructor_prior_podium_rate",
    "constructor_prior_mean_points",
    "driver_circuit_prior_starts",
    "driver_circuit_prior_podium_rate",
    "driver_prior_standing_points",
    "driver_prior_standing_position",
    "constructor_prior_standing_points",
    "constructor_prior_standing_position",
]

missing_features = [
    c for c in PERSON2_ALLOWED_FEATURES
    if c not in df.columns
]

if missing_features:
    raise ValueError(f"Missing Person 2 features: {missing_features}")

feature_cols = PERSON2_ALLOWED_FEATURES.copy()

print("Number of features:", len(feature_cols))
print(feature_cols)
assert PERSON2_ALLOWED_FEATURES == list(ALLOWED_FEATURES), "Feature contract changed"


work = df.dropna(subset=[target_col, year_col]).copy()

work[year_col] = pd.to_numeric(
    work[year_col],
    errors="coerce"
)

work = work.dropna(subset=[year_col])

train_df = work[
    work[year_col] <= 2019
].copy()

val_df = work[
    work[year_col].between(2020, 2021)
].copy()

test_df = work[
    work[year_col] >= 2022
].copy()

print("Train:", train_df.shape)
print("Validation:", val_df.shape)
print("Test:", test_df.shape)

print(
    "Train years:",
    int(train_df[year_col].min()),
    "-",
    int(train_df[year_col].max())
)

print(
    "Validation years:",
    int(val_df[year_col].min()),
    "-",
    int(val_df[year_col].max())
)

print(
    "Test years:",
    int(test_df[year_col].min()),
    "-",
    int(test_df[year_col].max())
)
assert len(work) == len(modeling_table), "No entrant may silently disappear"
for label, frame in [("train", train_df), ("validation", val_df), ("test", test_df)]:
    expected = modeling_table.loc[split_masks[label], ["raceId", "driverId"]]
    pd.testing.assert_frame_equal(frame[["raceId", "driverId"]], expected)


X_train_raw = train_df[feature_cols].copy()
y_train = train_df[target_col].astype(int).to_numpy()

X_val_raw = val_df[feature_cols].copy()
y_val = val_df[target_col].astype(int).to_numpy()

X_test_raw = test_df[feature_cols].copy()
y_test = test_df[target_col].astype(int).to_numpy()

print("Train podium rate:", round(y_train.mean(), 4))
print("Validation podium rate:", round(y_val.mean(), 4))
print("Test podium rate:", round(y_test.mean(), 4))

CATEGORICAL_RAW = ["circuitId"]

def build_preprocessor(X):
    categorical_cols = [
        c for c in CATEGORICAL_RAW
        if c in X.columns
    ]

    numeric_cols = [
        c for c in X.columns
        if c not in categorical_cols
    ]

    num_pipe = Pipeline([
        (
            "imputer",
            SimpleImputer(
                strategy="median",
                add_indicator=True
            )
        ),
        (
            "scaler",
            StandardScaler()
        )
    ])

    cat_pipe = Pipeline([
        (
            "imputer",
            SimpleImputer(
                strategy="most_frequent"
            )
        ),
        (
            "onehot",
            OneHotEncoder(
                handle_unknown="ignore",
                sparse_output=False
            )
        )
    ])

    transformers = [
        ("num", num_pipe, numeric_cols)
    ]

    if categorical_cols:
        transformers.append(
            ("cat", cat_pipe, categorical_cols)
        )

    preprocessor = ColumnTransformer(
        transformers=transformers,
        remainder="drop"
    )

    return (
        preprocessor,
        numeric_cols,
        categorical_cols
    )

for split_x in [
    X_train_raw,
    X_val_raw,
    X_test_raw
]:
    split_x["circuitId"] = (
        split_x["circuitId"]
        .astype("string")
    )

preprocessor, numeric_cols, categorical_cols = (
    build_preprocessor(X_train_raw)
)

X_train = np.asarray(
    preprocessor.fit_transform(X_train_raw),
    dtype=np.float32
)

X_val = np.asarray(
    preprocessor.transform(X_val_raw),
    dtype=np.float32
)

X_test = np.asarray(
    preprocessor.transform(X_test_raw),
    dtype=np.float32
)

print("X_train:", X_train.shape)
print("X_val:", X_val.shape)
print("X_test:", X_test.shape)

print("Numeric features:", len(numeric_cols))
print("Categorical features:", categorical_cols)

try:
    transformed_feature_names = (
        preprocessor
        .get_feature_names_out()
        .tolist()
    )
except Exception:
    transformed_feature_names = [
        f"x{i}"
        for i in range(X_train.shape[1])
    ]

print(
    "Number of transformed features:",
    len(transformed_feature_names)
)

print(
    "First 20 transformed features:"
)

print(
    transformed_feature_names[:20]
)

from sklearn.metrics import precision_score, recall_score

def best_f1_threshold(y_true, y_prob):
    precision, recall, thresholds = (
        precision_recall_curve(
            y_true,
            y_prob
        )
    )

    if len(thresholds) == 0:
        return 0.5

    f1_scores = (
        2 * precision[:-1] * recall[:-1]
        /
        np.clip(
            precision[:-1] + recall[:-1],
            1e-12,
            None
        )
    )

    best_index = int(
        np.nanargmax(f1_scores)
    )

    return float(
        thresholds[best_index]
    )


def evaluate_model(
    y_true,
    y_prob,
    threshold
):

    y_pred = (
        np.asarray(y_prob)
        >= threshold
    ).astype(int)

    return {
        "ROC-AUC":
            roc_auc_score(
                y_true,
                y_prob
            ),

        "PR-AUC":
            average_precision_score(
                y_true,
                y_prob
            ),

        "F1":
            f1_score(
                y_true,
                y_pred
            ),

        "Precision": precision_score(y_true, y_pred, zero_division=0),
        "Recall": recall_score(y_true, y_pred, zero_division=0),
        "Threshold":
            threshold
    }

def plot_roc_pr(
    y_true,
    y_prob,
    title_prefix
):

    # ROC
    fpr, tpr, _ = roc_curve(
        y_true,
        y_prob
    )

    roc_auc = roc_auc_score(
        y_true,
        y_prob
    )

    plt.figure(figsize=(6, 5))

    plt.plot(
        fpr,
        tpr,
        label=f"AUC = {roc_auc:.3f}"
    )

    plt.plot(
        [0, 1],
        [0, 1],
        linestyle="--"
    )

    plt.xlabel(
        "False Positive Rate"
    )

    plt.ylabel(
        "True Positive Rate"
    )

    plt.title(
        f"{title_prefix} — ROC Curve"
    )

    plt.legend()

    plt.show()


    # Precision Recall
    precision, recall, _ = (
        precision_recall_curve(
            y_true,
            y_prob
        )
    )

    pr_auc = (
        average_precision_score(
            y_true,
            y_prob
        )
    )

    plt.figure(figsize=(6, 5))

    plt.plot(
        recall,
        precision,
        label=f"PR-AUC = {pr_auc:.3f}"
    )

    plt.xlabel("Recall")

    plt.ylabel("Precision")

    plt.title(
        f"{title_prefix} — Precision Recall Curve"
    )

    plt.legend()

    plt.show()

def build_nn_trial_1(
    input_dim
):

    model = Sequential([
        Input(
            shape=(input_dim,)
        ),

        Dense(
            32,
            activation="relu"
        ),

        Dense(
            16,
            activation="relu"
        ),

        Dense(
            1,
            activation="sigmoid"
        )
    ])

    model.compile(
        optimizer="adam",
        loss="binary_crossentropy"
    )

    return model

def build_nn_trial_2(
    input_dim
):

    model = Sequential([
        Input(
            shape=(input_dim,)
        ),

        Dense(
            64,
            activation="relu"
        ),

        Dropout(
            0.20
        ),

        Dense(
            32,
            activation="relu"
        ),

        Dense(
            1,
            activation="sigmoid"
        )
    ])

    model.compile(
        optimizer="adam",
        loss="binary_crossentropy"
    )

    return model

def train_nn(
    builder,
    X_train,
    y_train,
    X_val,
    y_val,
    verbose=0
):

    tf.keras.backend.clear_session()

    random.seed(SEED)
    np.random.seed(SEED)
    tf.random.set_seed(SEED)

    tf.keras.utils.set_random_seed(SEED)

    model = builder(
        X_train.shape[1]
    )

    early_stopping = (
        EarlyStopping(
            monitor="val_loss",
            patience=8,
            min_delta=0.0001,
            restore_best_weights=True
        )
    )

    history = model.fit(
        X_train,
        y_train,

        validation_data=(
            X_val,
            y_val
        ),

        epochs=150,

        batch_size=32,

        callbacks=[
            early_stopping
        ],

        verbose=verbose
    )

    return (
        model,
        history
    )

model1, history1 = train_nn(
    build_nn_trial_1,

    X_train,
    y_train,

    X_val,
    y_val,

    verbose=1
)

def plot_history(
    history,
    title
):

    plt.figure(
        figsize=(7, 5)
    )

    plt.plot(
        history.history["loss"],
        label="Train Loss"
    )

    plt.plot(
        history.history["val_loss"],
        label="Validation Loss"
    )

    plt.xlabel("Epoch")

    plt.ylabel(
        "Binary Cross-Entropy Loss"
    )

    plt.title(title)

    plt.legend()

    plt.show()

plot_history(
    history1,
    "NN Trial 1 Training History"
)

val_prob_1 = (
    model1
    .predict(
        X_val,
        verbose=0
    )
    .ravel()
)

threshold_1 = (
    best_f1_threshold(
        y_val,
        val_prob_1
    )
)

results_1 = (
    evaluate_model(
        y_val,
        val_prob_1,
        threshold_1
    )
)

print(
    "Trial 1 threshold:",
    threshold_1
)

print(
    results_1
)

model2, history2 = train_nn(
    build_nn_trial_2,

    X_train,
    y_train,

    X_val,
    y_val,

    verbose=1
)

plot_history(
    history2,
    "NN Trial 2 Training History"
)

val_prob_2 = (
    model2
    .predict(
        X_val,
        verbose=0
    )
    .ravel()
)

threshold_2 = (
    best_f1_threshold(
        y_val,
        val_prob_2
    )
)

results_2 = (
    evaluate_model(
        y_val,
        val_prob_2,
        threshold_2
    )
)

print(
    "Trial 2 threshold:",
    threshold_2
)

print(
    results_2
)

nn_comparison = pd.DataFrame([
    {
        "Model":
            "NN Trial 1 (32-16)",

        **results_1
    },

    {
        "Model":
            "NN Trial 2 (64-32 + Dropout)",

        **results_2
    }
])

nn_comparison = (
    nn_comparison
    .sort_values(
        by=[
            "PR-AUC",
            "F1"
        ],
        ascending=False
    )
    .reset_index(drop=True)
)

display(
    nn_comparison
)

winner = (
    nn_comparison
    .iloc[0]["Model"]
)

if winner.startswith(
    "NN Trial 1"
):

    best_model = model1

    best_threshold = (
        threshold_1
    )

    best_label = (
        "NN Trial 1"
    )

else:

    best_model = model2

    best_threshold = (
        threshold_2
    )

    best_label = (
        "NN Trial 2"
    )


print(
    "Selected model:",
    best_label
)

print(
    "Selected threshold:",
    round(
        best_threshold,
        4
    )
)

best_val_prob = (
    best_model
    .predict(
        X_val,
        verbose=0
    )
    .ravel()
)

plot_roc_pr(
    y_val,
    best_val_prob,
    f"{best_label} Validation"
)

split_results = []

for (
    split_name,
    X_split,
    y_split
) in [

    (
        "Train",
        X_train,
        y_train
    ),

    (
        "Validation",
        X_val,
        y_val
    ),

    (
        "Test",
        X_test,
        y_test
    )
]:

    probabilities = (
        best_model
        .predict(
            X_split,
            verbose=0
        )
        .ravel()
    )

    metrics = (
        evaluate_model(
            y_split,
            probabilities,
            best_threshold
        )
    )

    split_results.append({
        "Split":
            split_name,

        **metrics
    })


final_nn_results = (
    pd.DataFrame(
        split_results
    )
)

display(
    final_nn_results
)

split_results = []

for (
    split_name,
    X_split,
    y_split
) in [

    (
        "Train",
        X_train,
        y_train
    ),

    (
        "Validation",
        X_val,
        y_val
    ),

    (
        "Test",
        X_test,
        y_test
    )
]:

    probabilities = (
        best_model
        .predict(
            X_split,
            verbose=0
        )
        .ravel()
    )

    metrics = (
        evaluate_model(
            y_split,
            probabilities,
            best_threshold
        )
    )

    split_results.append({
        "Split":
            split_name,

        **metrics
    })


final_nn_results = (
    pd.DataFrame(
        split_results
    )
)

display(
    final_nn_results
)

test_prob = (
    best_model
    .predict(
        X_test,
        verbose=0
    )
    .ravel()
)

test_pred = (
    test_prob
    >= best_threshold
).astype(int)


print(
    classification_report(
        y_test,
        test_pred,
        digits=4
    )
)

cm = confusion_matrix(
    y_test,
    test_pred
)

cm_df = pd.DataFrame(
    cm,

    index=[
        "Actual Non-Podium",
        "Actual Podium"
    ],

    columns=[
        "Predicted Non-Podium",
        "Predicted Podium"
    ]
)

display(
    cm_df
)

plot_roc_pr(
    y_test,
    test_prob,
    f"{best_label} Unseen Test"
)

feature_groups = {

    "grid": [
        "grid_position"
    ],

    "qualifying": [
        "qualifying_position"
    ],

    "driver_form": [
        "driver_prior_starts",
        "driver_prior_podium_rate",
        "driver_prior_mean_finish",
        "driver_circuit_prior_starts",
        "driver_circuit_prior_podium_rate"
    ],

    "constructor_form": [
        "constructor_prior_podium_rate",
        "constructor_prior_mean_points"
    ],

    "standings": [
        "driver_prior_standing_points",
        "driver_prior_standing_position",
        "constructor_prior_standing_points",
        "constructor_prior_standing_position"
    ],

    "context": [
        "year",
        "circuitId",
        "is_home_race"
    ]
}


for group_name, cols in (
    feature_groups.items()
):

    print(
        group_name,
        "->",
        cols
    )

selected_builder = (
    build_nn_trial_1
    if best_label == "NN Trial 1"
    else build_nn_trial_2
)


def run_ablation(
    raw_train,
    y_train,
    raw_val,
    y_val,
    base_features,
    feature_groups
):

    rows = []


    def fit_and_score(
        selected_features,
        experiment_name
    ):

        train_part = (
            raw_train[
                selected_features
            ].copy()
        )

        val_part = (
            raw_val[
                selected_features
            ].copy()
        )


        if "circuitId" in train_part.columns:

            train_part[
                "circuitId"
            ] = (
                train_part[
                    "circuitId"
                ].astype("string")
            )

            val_part[
                "circuitId"
            ] = (
                val_part[
                    "circuitId"
                ].astype("string")
            )


        prep, _, _ = (
            build_preprocessor(
                train_part
            )
        )


        Xt = np.asarray(
            prep.fit_transform(
                train_part
            ),
            dtype=np.float32
        )


        Xv = np.asarray(
            prep.transform(
                val_part
            ),
            dtype=np.float32
        )


        model, _ = train_nn(
            selected_builder,
            Xt,
            y_train,
            Xv,
            y_val,
            verbose=0
        )


        prob = (
            model
            .predict(
                Xv,
                verbose=0
            )
            .ravel()
        )


        threshold = (
            best_f1_threshold(
                y_val,
                prob
            )
        )


        metrics = (
            evaluate_model(
                y_val,
                prob,
                threshold
            )
        )


        rows.append({
            "Experiment":
                experiment_name,

            "Raw Feature Count":
                len(
                    selected_features
                ),

            **metrics
        })


        return metrics


    full_metrics = fit_and_score(
        base_features,
        "Full Feature Set"
    )


    for (
        group_name,
        group_columns
    ) in feature_groups.items():

        remaining = [
            feature
            for feature in base_features
            if feature
            not in group_columns
        ]


        fit_and_score(
            remaining,
            f"Without {group_name}"
        )


    results = pd.DataFrame(
        rows
    )


    results[
        "Δ PR-AUC vs Full"
    ] = (
        results["PR-AUC"]
        -
        full_metrics["PR-AUC"]
    )


    results[
        "Δ ROC-AUC vs Full"
    ] = (
        results["ROC-AUC"]
        -
        full_metrics["ROC-AUC"]
    )


    results[
        "Δ F1 vs Full"
    ] = (
        results["F1"]
        -
        full_metrics["F1"]
    )


    return results

ablation_results = (
    run_ablation(
        X_train_raw,
        y_train,

        X_val_raw,
        y_val,

        feature_cols,
        feature_groups
    )
)

display(
    ablation_results
)

display(
    ablation_results
    .sort_values(
        "PR-AUC",
        ascending=False
    )
)

ablation_plot = (
    ablation_results
    .set_index(
        "Experiment"
    )["PR-AUC"]
    .sort_values()
)

plt.figure(
    figsize=(9, 5)
)

ablation_plot.plot(
    kind="barh"
)

plt.xlabel(
    "Validation PR-AUC"
)

plt.title(
    "Feature Group Ablation"
)

plt.tight_layout()

plt.show()

from sklearn.preprocessing import QuantileTransformer

order_pipelines = {
    "impute_then_scale": Pipeline([
        ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
        ("scaler", StandardScaler())]),
    "scale_then_impute": Pipeline([
        ("scaler", StandardScaler()),
        ("imputer", SimpleImputer(strategy="median", add_indicator=True))]),
    "impute_then_quantile_then_scale": Pipeline([
        ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
        ("quantile", QuantileTransformer(n_quantiles=100, output_distribution="normal", random_state=SEED)),
        ("scaler", StandardScaler())]),
    "quantile_then_impute_then_scale": Pipeline([
        ("quantile", QuantileTransformer(n_quantiles=100, output_distribution="normal", random_state=SEED)),
        ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
        ("scaler", StandardScaler())]),
}
order_rows = []
order_distribution_rows = []
order_preprocessors = {}
for name, numeric_pipeline in order_pipelines.items():
    experiment_prep = ColumnTransformer([
        ("num", numeric_pipeline, numeric_cols),
        ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                          ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))]), categorical_cols)])
    train_matrix = np.asarray(experiment_prep.fit_transform(X_train_raw), dtype=np.float32)
    validation_matrix = np.asarray(experiment_prep.transform(X_val_raw), dtype=np.float32)
    order_preprocessors[name] = experiment_prep
    assert np.isfinite(train_matrix).all() and np.isfinite(validation_matrix).all()
    if name == "impute_then_scale":
        np.testing.assert_allclose(train_matrix, X_train, atol=1e-6)
        experiment_probability = best_val_prob
        trained_epochs = len(history1.history["loss"]) if best_label == "NN Trial 1" else len(history2.history["loss"])
    else:
        experiment_model, experiment_history = train_nn(selected_builder, train_matrix, y_train,
            validation_matrix, y_val, verbose=0)
        experiment_probability = experiment_model.predict(validation_matrix, verbose=0).ravel()
        trained_epochs = len(experiment_history.history["loss"])
    experiment_threshold = best_f1_threshold(y_val, experiment_probability)
    order_rows.append({"Order": name, "transformed_columns": train_matrix.shape[1],
        "epochs": trained_epochs, **evaluate_model(y_val, experiment_probability, experiment_threshold)})
    for j, feature_name in enumerate(experiment_prep.get_feature_names_out()):
        values = train_matrix[:, j]
        order_distribution_rows.append({"Order": name, "feature": feature_name,
            "mean": float(values.mean()), "std": float(values.std()),
            "min": float(values.min()), "max": float(values.max()),
            "missing_fraction": float(np.isnan(values).mean())})
order_results = pd.DataFrame(order_rows)
order_distribution = pd.DataFrame(order_distribution_rows)
display(order_results)
display(order_distribution.groupby("Order").agg(columns=("feature", "size"),
    average_std=("std", "mean"), lowest_value=("min", "min"), highest_value=("max", "max")))
order_results.set_index("Order")[["PR-AUC", "ROC-AUC", "F1"]].plot(kind="barh", figsize=(11, 5))
plt.xlabel("Validation score")
plt.title("Two preprocessing-order comparisons — fixed NN architecture")
plt.tight_layout()
plt.show()


def permutation_importance_pr_auc(
    model,
    X,
    y,
    feature_names,
    repeats=3
):

    rng = np.random.default_rng(
        SEED
    )

    baseline_probability = (
        model
        .predict(
            X,
            verbose=0
        )
        .ravel()
    )

    baseline_score = (
        average_precision_score(
            y,
            baseline_probability
        )
    )

    rows = []


    for column_index, feature_name in (
        enumerate(feature_names)
    ):

        score_drops = []


        for _ in range(repeats):

            X_permuted = (
                X.copy()
            )

            rng.shuffle(
                X_permuted[
                    :,
                    column_index
                ]
            )

            perm_probability = (
                model
                .predict(
                    X_permuted,
                    verbose=0
                )
                .ravel()
            )

            perm_score = (
                average_precision_score(
                    y,
                    perm_probability
                )
            )

            score_drops.append(
                baseline_score
                -
                perm_score
            )


        rows.append({
            "Feature":
                feature_name,

            "Importance_PR_AUC_Drop":
                float(
                    np.mean(
                        score_drops
                    )
                ),

            "Std":
                float(
                    np.std(
                        score_drops
                    )
                )
        })


    return (
        pd.DataFrame(
            rows
        )
        .sort_values(
            "Importance_PR_AUC_Drop",
            ascending=False
        )
        .reset_index(drop=True)
    )

permutation_df = (
    permutation_importance_pr_auc(
        best_model,

        X_val,
        y_val,

        transformed_feature_names,

        repeats=3
    )
)

display(
    permutation_df.head(20)
)

top_permutation = (
    permutation_df
    .head(20)
    .sort_values(
        "Importance_PR_AUC_Drop"
    )
)

plt.figure(
    figsize=(9, 7)
)

plt.barh(
    top_permutation["Feature"],
    top_permutation[
        "Importance_PR_AUC_Drop"
    ]
)

plt.xlabel(
    "Decrease in Validation PR-AUC"
)

plt.title(
    "Permutation Importance — Top 20"
)

plt.tight_layout()

plt.show()

print(
    "SHAP available:",
    SHAP_AVAILABLE
)

if SHAP_AVAILABLE:

    rng = np.random.default_rng(
        SEED
    )

    background_size = min(
        30,
        len(X_train)
    )

    explanation_size = min(
        25,
        len(X_val)
    )


    background_indices = (
        rng.choice(
            len(X_train),
            size=background_size,
            replace=False
        )
    )


    explanation_indices = (
        rng.choice(
            len(X_val),
            size=explanation_size,
            replace=False
        )
    )


    X_background = (
        X_train[
            background_indices
        ]
    )


    X_explain = (
        X_val[
            explanation_indices
        ]
    )


    print(
        "Background shape:",
        X_background.shape
    )

    print(
        "Explanation shape:",
        X_explain.shape
    )

if SHAP_AVAILABLE:

    def shap_predict(
        x
    ):

        x = np.asarray(
            x,
            dtype=np.float32
        )

        return (
            best_model
            .predict(
                x,
                verbose=0
            )
            .ravel()
        )


    shap_explainer = (
        shap.KernelExplainer(
            shap_predict,
            X_background
        )
    )

if SHAP_AVAILABLE:

    shap_values = (
        shap_explainer
        .shap_values(
            X_explain,
            nsamples=100
        )
    )


    if isinstance(
        shap_values,
        list
    ):

        shap_values = (
            shap_values[0]
        )


    shap_values = np.asarray(
        shap_values
    )


    print(
        "SHAP values shape:",
        shap_values.shape
    )

if SHAP_AVAILABLE:

    X_explain_df = (
        pd.DataFrame(
            X_explain,
            columns=
                transformed_feature_names
        )
    )


    shap.summary_plot(
        shap_values,

        X_explain_df,

        max_display=20,

        show=False
    )


    plt.title(
        "Global SHAP Summary — Neural Network"
    )

    plt.tight_layout()

    plt.show()

if SHAP_AVAILABLE:

    local_index = 0

    local_values = (
        shap_values[
            local_index
        ]
    )

    local_input = (
        X_explain[
            local_index
        ]
    )


    expected_value = (
        np.asarray(
            shap_explainer
            .expected_value
        )
        .reshape(-1)[0]
    )


    local_explanation = (
        shap.Explanation(
            values=
                local_values,

            base_values=
                expected_value,

            data=
                local_input,

            feature_names=
                transformed_feature_names
        )
    )


    local_probability = float(
        best_model
        .predict(
            local_input
            .reshape(1, -1),

            verbose=0
        )
        .ravel()[0]
    )


    print(
        "Predicted podium probability:",
        round(
            local_probability,
            4
        )
    )


    shap.plots.waterfall(
        local_explanation,

        max_display=15,

        show=False
    )


    plt.title(
        "Local SHAP Explanation"
    )

    plt.tight_layout()

    plt.show()

def predict_podium(
    record
):

    if isinstance(
        record,
        dict
    ):

        row = pd.DataFrame(
            [record]
        )

    elif isinstance(
        record,
        pd.Series
    ):

        row = (
            record
            .to_frame()
            .T
        )

    elif isinstance(
        record,
        pd.DataFrame
    ):

        row = (
            record.copy()
        )

    else:

        raise TypeError(
            "record must be dict, Series or DataFrame"
        )


    if len(row) != 1:
        raise ValueError("predict_podium expects exactly one driver–race record")

    for feature in feature_cols:

        if feature not in row.columns:

            row[
                feature
            ] = np.nan


    row = row[
        feature_cols
    ].copy()


    # Normalize categories exactly as during fit; represent missing categories as np.nan.
    def normalize_circuit_id(value):
        if pd.isna(value):
            return np.nan
        try:
            number = float(value)
            return str(int(number)) if np.isfinite(number) and number.is_integer() else str(value)
        except (TypeError, ValueError):
            return str(value)
    row["circuitId"] = row["circuitId"].map(normalize_circuit_id)
    for column in numeric_cols:
        row[column] = pd.to_numeric(row[column], errors="coerce")

    X_new = np.asarray(
        preprocessor
        .transform(
            row
        ),

        dtype=np.float32
    )


    probability = float(
        best_model
        .predict(
            X_new,
            verbose=0
        )
        .ravel()[0]
    )


    prediction = int(
        probability
        >= best_threshold
    )


    return {
        "podium_probability":
            probability,

        "podium_prediction":
            prediction,

        "threshold":
            float(
                best_threshold
            )
    }

complete_record = (
    X_test_raw
    .dropna()
    .iloc[0]
    .copy()
)

complete_prediction = (
    predict_podium(
        complete_record
    )
)

print(
    "Complete Record"
)

print(
    complete_prediction
)

partially_missing_record = (
    complete_record.copy()
)

missing_demo_features = [
    "qualifying_position",
    "driver_prior_podium_rate",
    "constructor_prior_standing_position"
]

for feature in (
    missing_demo_features
):

    partially_missing_record[
        feature
    ] = np.nan


missing_prediction = (
    predict_podium(
        partially_missing_record
    )
)


print(
    "Partially Missing Record"
)

print(
    "Missing:",
    missing_demo_features
)

print(
    missing_prediction
)

print(
    "FINAL PERSON 4 SUMMARY"
)

print(
    "----------------------"
)

print(
    "Best neural network:",
    best_label
)

print(
    "Threshold:",
    round(
        best_threshold,
        4
    )
)

print(
    "\\nTrain / Validation / Test:"
)

display(
    final_nn_results
)

print(
    "\\nAblation results:"
)

display(
    ablation_results
)

print(
    "\\nTop 10 permutation features:"
)

display(
    permutation_df
    .head(10)
)

nn_for_comparison = final_nn_results.rename(columns={"Split": "split", "ROC-AUC": "ROC_AUC", "PR-AUC": "PR_AUC_AP",
    "Precision": "precision", "Recall": "recall", "Threshold": "threshold"}).copy()
nn_for_comparison["split"] = nn_for_comparison["split"].str.lower()
nn_for_comparison["model"] = best_label + " (shallow NN)"
nn_for_comparison["rows"] = nn_for_comparison["split"].map(split_summary.set_index("split")["rows"])
comparison_columns = ["model", "split", "rows", "ROC_AUC", "PR_AUC_AP", "F1", "precision", "recall", "threshold"]
all_model_comparison = pd.concat([model_comparison[comparison_columns], nn_for_comparison[comparison_columns]], ignore_index=True)
display(all_model_comparison.round(4))

narrative = [f"Selected {best_label} by validation AP; frozen threshold {best_threshold:.4f}."]
for row in final_nn_results.to_dict("records"):
    narrative.append(f"{row['Split']}: ROC-AUC {row['ROC-AUC']:.4f}, AP {row['PR-AUC']:.4f}, F1 {row['F1']:.4f}, precision {row['Precision']:.4f}, recall {row['Recall']:.4f}.")
worst_removal = ablation_results.loc[ablation_results["Experiment"].ne("Full Feature Set")].sort_values("Δ PR-AUC vs Full").iloc[0]
narrative.append(f"Most negative ablation change: {worst_removal['Experiment']}, validation AP delta {worst_removal['Δ PR-AUC vs Full']:+.4f}. This is a one-seed model comparison, not a causal effect.")
for left, right in [("impute_then_scale", "scale_then_impute"),
                    ("impute_then_quantile_then_scale", "quantile_then_impute_then_scale")]:
    vals = order_results.set_index("Order")["PR-AUC"]
    narrative.append(f"Order comparison {left} versus {right}: validation AP {vals[left]:.4f} versus {vals[right]:.4f}; no test-driven change to the selected model.")
narrative.append("Largest positive permutation AP drops: " + "; ".join(f"{row.Feature}: {row.Importance_PR_AUC_Drop:+.4f}" for row in permutation_df.head(5).itertuples()) + ". Transformed-column shuffles may break valid dummy/indicator combinations.")
shap_ranking = pd.DataFrame({"feature": transformed_feature_names,
    "mean_abs_SHAP": np.abs(shap_values).mean(axis=0)}).sort_values("mean_abs_SHAP", ascending=False)
narrative.append("Largest sample mean absolute SHAP contributions: " + "; ".join(f"{row.feature}: {row.mean_abs_SHAP:.4f}" for row in shap_ranking.head(5).itertuples()) + ". These are approximate probability attributions on sampled validation records.")
local_keys = val_df.iloc[int(explanation_indices[local_index])][["raceId", "driverId"]].to_dict()
local_contributions = pd.DataFrame({"feature": transformed_feature_names, "SHAP": local_values}).assign(abs_SHAP=lambda x: x["SHAP"].abs()).sort_values("abs_SHAP", ascending=False)
narrative.append(f"Local case {local_keys}: probability {local_probability:.4f}, baseline {float(expected_value):.4f}. Largest signed contributions: " + "; ".join(f"{row.feature}: {row.SHAP:+.4f}" for row in local_contributions.head(5).itertuples()) + ". This explanation is specific to that record.")
narrative.append(f"Complete-input prediction: {complete_prediction}. Partial-input prediction: {missing_prediction}. Missing fields: {missing_demo_features}.")
narrative.append("Permutation importance and SHAP describe model reliance, not causality. Era drift, missing qualifying history, inferred historical starts, correlated features and small explanation samples remain limitations. The notebook’s analyses and plots must also appear in the separate PDF report.")
person4_interpretation = "\n\n".join(narrative)
display(Markdown(person4_interpretation))
for name, table in [("nn_trials.csv", nn_comparison), ("nn_metrics.csv", final_nn_results),
    ("all_model_comparison.csv", all_model_comparison), ("ablation_results.csv", ablation_results),
    ("preprocessing_order_results.csv", order_results), ("preprocessing_order_distributions.csv", order_distribution),
    ("permutation_importance.csv", permutation_df), ("shap_global_ranking.csv", shap_ranking),
    ("shap_local_contributions.csv", local_contributions)]:
    table.to_csv(PERSON4_OUTPUT_DIR / name, index=False)
np.savez_compressed(PERSON4_OUTPUT_DIR / "shap_values.npz", values=shap_values,
    transformed_inputs=X_explain, background_indices=background_indices,
    validation_indices=explanation_indices, expected_value=float(expected_value))
(PERSON4_OUTPUT_DIR / "interpretation.md").write_text(person4_interpretation, encoding="utf-8")
(PERSON4_OUTPUT_DIR / "inference_examples.json").write_text(json.dumps({"complete": complete_prediction,
    "partially_missing": missing_prediction, "removed_features": missing_demo_features}, indent=2))
pd.DataFrame({"plot_file": person4_plot_files}).to_csv(PERSON4_OUTPUT_DIR / "plot_manifest.csv", index=False)
for name, frame in tables_clean.items():
    assert pd.util.hash_pandas_object(frame, index=True).sum() == person4_input_fingerprints[name]
assert pd.util.hash_pandas_object(modeling_table, index=True).sum() == person4_model_fingerprint
