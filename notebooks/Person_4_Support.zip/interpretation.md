Selected NN Trial 2 by validation AP; frozen threshold 0.2022.

Train: ROC-AUC 0.9283, AP 0.6460, F1 0.6086, precision 0.4909, recall 0.8005.

Validation: ROC-AUC 0.9397, AP 0.7619, F1 0.7237, precision 0.6643, recall 0.7949.

Test: ROC-AUC 0.9342, AP 0.6882, F1 0.6490, precision 0.5904, recall 0.7206.

Most negative ablation change: Without grid, validation AP delta -0.0323. This is a one-seed model comparison, not a causal effect.

Order comparison impute_then_scale versus scale_then_impute: validation AP 0.7619 versus 0.7490; no test-driven change to the selected model.

Order comparison impute_then_quantile_then_scale versus quantile_then_impute_then_scale: validation AP 0.6903 versus 0.6993; no test-driven change to the selected model.

Largest positive permutation AP drops: num__grid_position: +0.1573; num__driver_prior_podium_rate: +0.0916; num__driver_prior_standing_points: +0.0791; num__qualifying_position: +0.0790; num__driver_circuit_prior_starts: +0.0314. Transformed-column shuffles may break valid dummy/indicator combinations.

Largest sample mean absolute SHAP contributions: num__grid_position: 0.0584; num__qualifying_position: 0.0334; num__year: 0.0313; num__driver_prior_standing_points: 0.0136; num__driver_prior_podium_rate: 0.0133. These are approximate probability attributions on sampled validation records.

Local case {'raceId': 1067, 'driverId': 839}: probability 0.0008, baseline 0.1273. Largest signed contributions: num__year: -0.0374; cat__circuitId_5: -0.0328; num__grid_position: -0.0256; num__driver_prior_standing_points: +0.0156; num__driver_prior_podium_rate: -0.0154. This explanation is specific to that record.

Complete-input prediction: {'podium_probability': 0.04016012325882912, 'podium_prediction': 0, 'threshold': 0.20224826037883759}. Partial-input prediction: {'podium_probability': 0.015244712121784687, 'podium_prediction': 0, 'threshold': 0.20224826037883759}. Missing fields: ['qualifying_position', 'driver_prior_podium_rate', 'constructor_prior_standing_position'].

Permutation importance and SHAP describe model reliance, not causality. Era drift, missing qualifying history, inferred historical starts, correlated features and small explanation samples remain limitations. The notebook’s analyses and plots must also appear in the separate PDF report.