# Person 4: Zeina's NN, experiments, XAI and inference

Source: notebooks/notebook1288119367_structured (1).ipynb on zeina at 7aa179c191a74b400e83cb4dedc783324390a46e (see branch/source preservation record for authoritative SHA). Integrated after main 4edf9e4667dbb206e438d5078998f8fdd11686f8 in notebooks/part1completed.ipynb. The older part4_updated_person2.ipynb is superseded by Zeina's newer structured notebook. Her earlier P1/P2 copies are not duplicated in the combined notebook.

Preservation and required changes:
- All 94 existing P1/P2/P3 source cells are preserved. Cleaned tables and modeling_table are fingerprinted unchanged by P4.
- 39 of Zeina's 47 original P4 code cells are exactly unchanged. Original code cells 62, 65, 67, 69, 76, 81, 133 and 134 have targeted changes: required dependency failures, controlled threads, stronger input/row/feature validation, required precision/recall, Keras seed reset, one-row/missing-category inference handling, and a truly complete demo record. Architectures, trial selection, original preprocessing, ablation, transformed-column permutation and global/local Kernel SHAP methods are retained.
- Fixed narrative percentages/rankings from the old dataset are replaced by fresh tables/plots and a computed narrative. No claim relies on old stored results.
- Two preprocessing-order experiments were missing from the branch: impute/scale order, and impute/quantile-transform order. Four conditions compare these pairs with the same raw features, selected architecture, seed and chronological rows. All preprocessing is fitted on training; scores/thresholds use validation only. They do not modify the frozen model based on test scores.
- Adds the shared three-model comparison table with ROC-AUC, AP (the PR-AUC convention), F1, precision and recall, plus automatic plot/result exports.

Run All with the Kaggle F1 CSV dataset attached. Local configuration: F1_DATA_DIR points to all 14 CSVs; F1_OUTPUT_DIR, F1_PERSON2_OUTPUT_DIR, F1_PERSON3_OUTPUT_DIR and F1_PERSON4_OUTPUT_DIR point to separate output directories. P1's directory must contain only its ten figures for its existing manifest check. Set CPU thread counts through the documented environment if desired. The Python export in this archive contains only P4 and requires the preceding notebook namespace.

Data/model contract:
- Same 26,668 entrant driver-race rows and 16 allowed P2 features across all three models.
- Train through 2019; validation 2020-2021; test 2022-2024. The exact split keys are asserted equal to P3.
- Numeric training median imputation with indicators and standardization; circuit is nominal and one-hot encoded.
- Two original shallow NN architectures: 32/16 ReLU and 64/32 ReLU with 20% dropout. Training uses Adam/binary cross entropy, maximum 150 epochs, validation-loss early stopping patience 8/min_delta .0001, restoring best weights.
- Architecture uses validation AP and F1 tie-breaker; threshold maximizes validation F1. No test-driven tuning, feature changes or threshold changes.
- Ablation covers all six groups and full model. One seeded run per condition has no statistical uncertainty estimate; input dimension/optimization effects can contribute.

XAI/inference:
- Permutation importance retains the original three shuffles per transformed column on validation, using AP decrease. Independent dummy/indicator shuffles may create invalid combinations; correlated predictors can mask importance.
- Global and local SHAP use the original 30 training-background and 25 validation-explanation rows, Kernel SHAP 100 coalition samples. Attributions approximate probability changes relative to that background. Finite sample/coalition budget, correlations and dummy constraints limit stability. Additivity checked on every explained row.
- Local record raceId/driverId and largest signed contributions are in interpretation.md and shap_local_contributions.csv. These explain model reliance, not causality.
- predict_podium accepts one dict, Series or one-row DataFrame; adds absent fields, normalizes nominal circuit IDs, uses training-fitted imputation and returns probability/prediction/frozen threshold. Complete and numeric-partial cases are demonstrated. Missing circuit, integer/float ID normalization, adapter consistency and multiple-row rejection are verified.

Validation: all code cells executed top to bottom in a fresh Python process with IPython; no saved notebook error outputs. The host denies Jupyter sockets, so no nbclient/kernel execution is claimed. See validation_results.json for exact cell/figure counts and tests, source_preservation_audit.json for original cell mapping, and validated_versions.json for dependencies. The model trials and diagnostic experiments were executed with the original architecture/training settings.

This notebook now contains P1-P4. The separate analytical PDF report and accessible Kaggle publication remain team submission deliverables. Copy all DE answers, model comparisons and XAI plots/interpretations into that report. Do not use these test scores to retune the final models.
