**Logistic Regression:** AP train/validation/test = 0.565/0.738/0.672; test ROC-AUC 0.932, F1 0.658, precision 0.615, recall 0.706. Threshold 0.422 was selected on validation only.

**Random Forest:** AP train/validation/test = 0.677/0.718/0.708; test ROC-AUC 0.938, F1 0.658, precision 0.665, recall 0.652. Threshold 0.442 was selected on validation only.