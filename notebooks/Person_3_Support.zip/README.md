# Person 3: Q3 and statistical models

Integrated from Sama's notebooks/part3.ipynb at eca7e72c2c9c5658060fdd376ad1a01a89968286, after P1/P2 on main bb75d6bf7bf122652cb7ebd3ba22c4449b6413c5.

The original Sama branch contained cleaning plus Q3, but no statistical ML section. The completed P1/P2 cells are retained, rather than repeating Sama's older cleaning copy. Original Q3 joins, counts inspection, aggregation and bar-chart structure are retained, with targeted corrections described below. Sama's original branch is not overwritten.

Changes needed for Q3:
- Use the already documented P2 inferred-start policy, with counts of nonstarter/unknown exclusions; withdrawals must not automatically count as starts. This is an operational inferred-start population, not a perfect historical entry/start list.
- Require an early ending (laps below maximum recorded in that race) for the recorded-cause mechanical numerator.
- Retain explicit component failures but exclude ambiguous generic/wing/undertray/wheel/fuel/stalling labels conservatively. No causal investigation is implied by a status label. All observed statuses are mapped and audited; crashes, driver and regulation outcomes cannot enter the mechanical numerator.
- Add join cardinality checks and assert unique grain; save plot and audit tables.
- Replace stale hand-entered percentages and causal era wording with dynamically generated results and limitations. Keep minimum 30 starts for the displayed constructor-era rankings; export all groups as well.

Missing conventional ML work added:
- Logistic Regression statistical baseline and Random Forest, each on P2's identical 26,668 entrant rows and 16 allowed features.
- Chronological train <=2019 (24,529 rows), validation 2020-2021 (780), test 2022-2024 (1,359), with justification in notebook.
- Train-only medians/missing indicators/scaling and nominal circuit imputation/one-hot inside pipelines. No retrospective status/start filter or current-race outcome predictor.
- Eight explicit tuning attempts retained; compare unweighted and balanced class weighting. Choose each family's hyperparameters by validation AP, ROC-AUC tie-breaker; choose its threshold by validation F1. Do not refit or select with test outcomes.
- Five required metrics ROC-AUC, AP (the stated PR-AUC convention), F1, precision and recall, plus accuracy, on all three splits. Shared curves, confusion matrices, predictions, tables and interpretations saved.
- Primary metric AP due class imbalance; secondary ROC-AUC. No tuning claims beyond the small documented grid.

Rerun: open notebooks/part1completed.ipynb in Kaggle with all 14 F1 CSVs attached and Run All. For local paths, set F1_DATA_DIR, F1_OUTPUT_DIR (P1, separate directory containing only its ten figures), F1_PERSON2_OUTPUT_DIR and F1_PERSON3_OUTPUT_DIR. The Python export here is only P3 and depends on P1/P2 variables; the combined notebook is the complete executable source. sklearn, numpy, pandas and matplotlib are required; validation used sklearn 1.8.0.

Execution validation: all 56 code cells ran in order in a fresh Python process with IPython and saved outputs. This environment denies Jupyter kernel sockets, so no nbclient/kernel run is claimed. Tests verified all 75 existing P1/P2 source cells and input frames unchanged; two untouched Sama evidence cells byte-for-byte; unique rows; full split coverage; train-only fitted medians/scaler means; validation-selected model scores and optimal thresholds; prediction counts, confusion matrices and F1 calculations; Q3 mapped statuses, eligible starts and early-ending numerators. No saved notebook error outputs.

This completes Person 3's listed Q3/statistical deliverables. Shallow NN, feature-group ablation, preprocessing-order experiments, XAI, inference and the separate report remain later team deliverables. Use the same allowed features/splits for the neural network. Copy Q3 and statistical figures/answers to the final report. Do not retune based on the recorded test scores.
