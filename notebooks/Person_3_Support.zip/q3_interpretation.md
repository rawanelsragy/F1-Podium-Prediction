**2014–2021:** Caterham: 23.53% (8/34); Lotus F1: 17.33% (13/75); Toro Rosso: 16.12% (39/242); McLaren: 13.52% (43/318); Renault: 13.50% (27/200). Era rate: 9.04%.

**2022–2024:** Alfa Romeo: 11.36% (10/88); Alpine F1 Team: 11.03% (15/136); AlphaTauri: 6.82% (6/88); Williams: 5.22% (7/134); Ferrari: 5.19% (7/135). Era rate: 5.47%.

Descriptive recorded-cause rates only, conditional on the documented inferred-start, early-ending and conservative status policies. No causal claim or significance test. Renamed constructors remain separate; displayed groups require at least 30 starts.