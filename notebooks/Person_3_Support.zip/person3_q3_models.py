# Run after the combined Person 1 and Person 2 sections.

PERSON3_OUTPUT_DIR = Path(os.environ.get("F1_PERSON3_OUTPUT_DIR", "/kaggle/working/person3_outputs"))
PERSON3_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
# Retain Person 1/2 inputs unchanged throughout this section.
person3_input_fingerprints = {name: pd.util.hash_pandas_object(frame, index=True).sum()
                              for name, frame in tables_clean.items()}
person3_model_fingerprint = pd.util.hash_pandas_object(modeling_table, index=True).sum()


res = tables_clean["results"].copy()
res["statusId"] = pd.to_numeric(res["statusId"], errors="coerce")
res["laps"] = pd.to_numeric(res["laps"], errors="coerce")

q3 = (
    res[["raceId", "driverId", "constructorId", "statusId", "laps", "grid"]]
    .merge(tables_clean["status"][["statusId", "status"]], on="statusId", how="left", validate="many_to_one")
    .merge(tables_clean["races"][["raceId", "year"]], on="raceId", how="left", validate="many_to_one")
    .merge(tables_clean["constructors"][["constructorId", "name"]], on="constructorId", how="left", validate="many_to_one")
    .rename(columns={"name": "constructor"})
)

q3 = q3[q3["year"].between(2014, 2024)].copy()
q3["era"] = np.where(q3["year"] <= 2021, "2014–2021", "2022–2024")

print("Rows 2014–2024:", len(q3))
print("Missing status after join:", q3["status"].isna().sum())
print("Missing constructor after join:", q3["constructor"].isna().sum())
assert not q3.duplicated(["raceId", "driverId"]).any()
assert q3[["status", "year", "constructor"]].notna().all().all()
q3["start_class"] = classify_start_status(q3)
race_distance = tables_clean["results"].groupby("raceId")["laps"].max()
q3["race_max_laps"] = q3["raceId"].map(race_distance)
q3["ended_early"] = q3["laps"].lt(q3["race_max_laps"])
q3_population_audit = q3.groupby(["era", "start_class"], observed=True).size().rename("rows").reset_index()
display(q3_population_audit)


status_counts = q3["status"].value_counts()
print("Distinct status values in 2014–2024:", len(status_counts))
status_counts

MECHANICAL = {
    "Engine", "Gearbox", "Transmission", "Clutch", "Hydraulics", "Electrical",
    "Radiator", "Suspension", "Brakes", "Differential", "Overheating", "Mechanical",
    "Driveshaft", "Fuel pressure", "Water pressure", "Wheel", "Throttle", "Steering",
    "Technical", "Electronics", "Exhaust", "Oil leak", "Wheel rim", "Water leak",
    "Fuel pump", "Track rod", "Oil pressure", "Engine fire", "Engine misfire",
    "Wheel nut", "Pneumatics", "Handling", "Fire", "Wheel bearing", "Fuel system",
    "Oil line", "Fuel leak", "Power loss", "Vibrations", "Drivetrain", "Ignition",
    "Chassis", "Battery", "Halfshaft", "Crankshaft", "Alternator", "Oil pump",
    "Injection", "Distributor", "Turbo", "CV joint", "Water pump", "Spark plugs",
    "Fuel pipe", "Oil pipe", "Axle", "Water pipe", "Magneto", "Supercharger",
    "Power Unit", "ERS", "Brake duct", "Seat", "Undertray", "Cooling system",
    "Heat shield fire", "Front wing", "Rear wing", "Broken wing", "Launch control",
    "Fuel", "Refuelling", "Stalled", "Driver Seat", "Safety belt",
}

ACCIDENT_DRIVER = {
    "Accident", "Collision", "Collision damage", "Spun off", "Damage", "Debris",
    "Fatal accident", "Injured", "Injury", "Eye injury", "Physical", "Illness",
    "Driver unwell",
}

NOT_STARTED = {
    "Did not qualify", "Did not prequalify", "107% Rule", "Did not start",
    "Not restarted",
}

OTHER = {
    "Disqualified", "Excluded", "Withdrew", "Retired", "Not classified",
    "Tyre", "Puncture", "Tyre puncture", "Out of fuel", "Underweight",
    "Safety", "Safety concerns", "Fuel rig",
}


def status_group(s):
    if pd.isna(s):
        return "unmapped"
    if s == "Finished" or str(s).startswith("+"):
        return "finished"
    if s in MECHANICAL:
        return "mechanical"
    if s in ACCIDENT_DRIVER:
        return "accident_driver"
    if s in NOT_STARTED:
        return "not_started"
    if s in OTHER:
        return "other"
    return "unmapped"


# Ambiguous causes cannot establish component failure from this label alone.
AMBIGUOUS_COMPONENT_LABELS = {
    "Handling", "Fire", "Fuel", "Refuelling", "Stalled", "Technical", "Vibrations",
    "Front wing", "Rear wing", "Broken wing", "Undertray", "Wheel", "Wheel nut",
    "Seat", "Driver Seat", "Safety belt", "Launch control",
}
MECHANICAL = MECHANICAL - AMBIGUOUS_COMPONENT_LABELS
OTHER = OTHER | AMBIGUOUS_COMPONENT_LABELS

q3["status_group"] = q3["status"].apply(status_group)

unmapped = q3.loc[q3["status_group"] == "unmapped", "status"].value_counts()
print("Unmapped statuses:", len(unmapped))
print(unmapped)

q3["status_group"].value_counts()
assert q3["status_group"].ne("unmapped").all(), "Review new/missing Q3 status labels"


starts = q3[q3["start_class"].eq("started")].copy()
starts["mechanical"] = (starts["status_group"].eq("mechanical") & starts["ended_early"]).astype(int)

MIN_STARTS = 30

mech_rates = (
    starts.groupby(["era", "constructor"])
    .agg(starts=("mechanical", "size"), mech_dnfs=("mechanical", "sum"))
    .reset_index()
)
mech_rates["mech_rate_pct"] = mech_rates["mech_dnfs"] / mech_rates["starts"] * 100
all_mech_rates = mech_rates.copy()
mech_rates = mech_rates[mech_rates["starts"] >= MIN_STARTS]

era_overall = starts.groupby("era")["mechanical"].mean() * 100
print("Overall mechanical-retirement rate per era (%):")
print(era_overall.round(2))

for era in ["2014–2021", "2022–2024"]:
    print(f"\nTop 5 constructors, {era}:")
    print(
        mech_rates[mech_rates["era"] == era]
        .sort_values("mech_rate_pct", ascending=False)
        .head(5)[["constructor", "starts", "mech_dnfs", "mech_rate_pct"]]
        .round(2)
        .to_string(index=False)
    )

fig, axes = plt.subplots(1, 2, figsize=(14, 6), sharex=True)

for ax, era in zip(axes, ["2014–2021", "2022–2024"]):
    d = mech_rates[mech_rates["era"] == era].sort_values("mech_rate_pct")
    ax.barh(d["constructor"], d["mech_rate_pct"])
    ax.axvline(era_overall[era], linestyle="--", color="gray",
               label=f"Era average ({era_overall[era]:.1f}%)")
    for y, (rate, n) in enumerate(zip(d["mech_rate_pct"], d["starts"])):
        ax.text(rate + 0.2, y, f"{rate:.1f}% (n={n})", va="center", fontsize=8)
    ax.set_title(f"Mechanical retirement rate, {era}")
    ax.set_xlabel("Mechanical retirements per race start (%)")
    ax.legend(loc="lower right")

plt.tight_layout()
fig.savefig(PERSON3_OUTPUT_DIR / "q3_mechanical_retirement_rates.png", dpi=160, bbox_inches="tight")
plt.show()

top_causes = (
    starts[starts["mechanical"] == 1]
    .groupby(["era", "status"])
    .size()
    .reset_index(name="count")
    .sort_values(["era", "count"], ascending=[True, False])
    .groupby("era")
    .head(6)
)
top_causes

q3_lines = []
for era in ["2014–2021", "2022–2024"]:
    leaders = mech_rates.loc[mech_rates["era"].eq(era)].nlargest(5, "mech_rate_pct")
    labels = [f"{r.constructor}: {r.mech_rate_pct:.2f}% ({r.mech_dnfs}/{r.starts})" for r in leaders.itertuples()]
    q3_lines.append(f"**{era}:** " + "; ".join(labels) + f". Era rate: {era_overall[era]:.2f}%.")
q3_interpretation = "\n\n".join(q3_lines) + "\n\nDescriptive recorded-cause rates only, conditional on the documented inferred-start, early-ending and conservative status policies. No causal claim or significance test. Renamed constructors remain separate; displayed groups require at least 30 starts."
display(Markdown(q3_interpretation))
q3_status_audit = q3.groupby(["era", "status", "status_group", "start_class", "ended_early"], dropna=False).size().rename("rows").reset_index()
all_mech_rates.to_csv(PERSON3_OUTPUT_DIR / "q3_all_constructor_rates.csv", index=False)
mech_rates.to_csv(PERSON3_OUTPUT_DIR / "q3_displayed_constructor_rates.csv", index=False)
q3_status_audit.to_csv(PERSON3_OUTPUT_DIR / "q3_status_audit.csv", index=False)
q3_population_audit.to_csv(PERSON3_OUTPUT_DIR / "q3_population_audit.csv", index=False)
top_causes.to_csv(PERSON3_OUTPUT_DIR / "q3_top_failure_causes.csv", index=False)
(PERSON3_OUTPUT_DIR / "q3_interpretation.md").write_text(q3_interpretation, encoding="utf-8")


from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (average_precision_score, roc_auc_score, f1_score,
    precision_score, recall_score, accuracy_score, precision_recall_curve,
    RocCurveDisplay, PrecisionRecallDisplay, ConfusionMatrixDisplay)
from sklearn.base import clone
import sklearn

FEATURES = list(ALLOWED_FEATURES)
assert "podium" not in FEATURES
split_masks = {"train": modeling_table["year"].le(2019),
               "validation": modeling_table["year"].between(2020, 2021),
               "test": modeling_table["year"].between(2022, 2024)}
assert sum(mask.astype(int) for mask in split_masks.values()).eq(1).all()
split_data = {name: (modeling_table.loc[mask, FEATURES].copy(),
                     modeling_table.loc[mask, "podium"].astype(int).copy())
              for name, mask in split_masks.items()}
split_summary = pd.DataFrame([{"split": name, "rows": int(mask.sum()),
    "first_year": int(modeling_table.loc[mask, "year"].min()),
    "last_year": int(modeling_table.loc[mask, "year"].max()),
    "podium_rate": float(modeling_table.loc[mask, "podium"].mean())}
    for name, mask in split_masks.items()])
display(split_summary)
assert split_summary["rows"].sum() == len(modeling_table)
assert all(y.nunique() == 2 for X, y in split_data.values())

numeric_features = [f for f in FEATURES if f != "circuitId"]
preprocessor = ColumnTransformer([
    ("numeric", Pipeline([("impute", SimpleImputer(strategy="median", add_indicator=True)),
                          ("scale", StandardScaler())]), numeric_features),
    ("circuit", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                          ("encode", OneHotEncoder(handle_unknown="ignore", sparse_output=False))]), ["circuitId"]),
])
X_train, y_train = split_data["train"]
X_validation, y_validation = split_data["validation"]
# Small, explicit tuning grids keep every attempt reviewable and Run All practical.
candidates = []
for weight in [None, "balanced"]:
    for C in [0.1, 1.0]:
        candidates.append(("Logistic Regression", {"C": C, "class_weight": weight},
            LogisticRegression(C=C, class_weight=weight, max_iter=3000, random_state=42)))
    for leaf, depth in [(2, None), (8, 12)]:
        candidates.append(("Random Forest", {"min_samples_leaf": leaf, "max_depth": depth, "class_weight": weight},
            RandomForestClassifier(n_estimators=150, min_samples_leaf=leaf, max_depth=depth,
                                   class_weight=weight, random_state=42, n_jobs=2)))


tuning_rows = []
selected_models = {}
selected_ranks = {}
for family, parameters, estimator in candidates:
    fitted = Pipeline([("preprocess", clone(preprocessor)), ("model", estimator)])
    fitted.fit(X_train, y_train)
    validation_probability = fitted.predict_proba(X_validation)[:, 1]
    ap = average_precision_score(y_validation, validation_probability)
    auc = roc_auc_score(y_validation, validation_probability)
    tuning_rows.append({"model": family, "parameters": json.dumps(parameters),
                        "validation_AP": ap, "validation_ROC_AUC": auc})
    if family not in selected_ranks or (ap, auc) > selected_ranks[family]:
        selected_models[family] = fitted
        selected_ranks[family] = (ap, auc)
tuning_results = pd.DataFrame(tuning_rows)
display(tuning_results)
thresholds = {}
selection_rows = []
for family, fitted in selected_models.items():
    probability = fitted.predict_proba(X_validation)[:, 1]
    precision, recall, candidate_thresholds = precision_recall_curve(y_validation, probability)
    scores = 2 * precision[:-1] * recall[:-1] / np.maximum(precision[:-1] + recall[:-1], 1e-15)
    best_index = int(np.argmax(scores)) # deterministic first threshold among ties
    thresholds[family] = float(candidate_thresholds[best_index])
    selection_rows.append({"model": family, "threshold": thresholds[family],
                           "validation_F1": float(scores[best_index]),
                           "parameters": json.dumps(fitted.named_steps["model"].get_params(), default=str)})
selection_results = pd.DataFrame(selection_rows)
display(selection_results[["model", "threshold", "validation_F1"]])
# Frozen choices. Test is not used to select either a candidate or threshold.
frozen_selection = selection_results.copy(deep=True)


metric_rows = []
model_predictions = {}
for family, fitted in selected_models.items():
    for split, (X_part, y_part) in split_data.items():
        probability = fitted.predict_proba(X_part)[:, 1]
        prediction = (probability >= thresholds[family]).astype(int)
        model_predictions[(family, split)] = (probability, prediction)
        metric_rows.append({"model": family, "split": split, "rows": len(y_part),
            "threshold": thresholds[family], "ROC_AUC": roc_auc_score(y_part, probability),
            "PR_AUC_AP": average_precision_score(y_part, probability),
            "F1": f1_score(y_part, prediction, zero_division=0),
            "precision": precision_score(y_part, prediction, zero_division=0),
            "recall": recall_score(y_part, prediction, zero_division=0),
            "accuracy": accuracy_score(y_part, prediction)})
model_comparison = pd.DataFrame(metric_rows)
display(model_comparison.round(4))
fig, axes = plt.subplots(2, 2, figsize=(13, 10))
for row, split in enumerate(["validation", "test"]):
    y_part = split_data[split][1]
    for family in selected_models:
        probability = model_predictions[(family, split)][0]
        RocCurveDisplay.from_predictions(y_part, probability, name=family, ax=axes[row, 0])
        PrecisionRecallDisplay.from_predictions(y_part, probability, name=family, ax=axes[row, 1])
    axes[row, 0].plot([0, 1], [0, 1], "--", color="gray", label="Chance")
    axes[row, 1].axhline(y_part.mean(), linestyle="--", color="gray", label="Prevalence")
    axes[row, 0].set_title(f"{split.title()} ROC curves")
    axes[row, 1].set_title(f"{split.title()} precision–recall curves")
    for ax in axes[row]: ax.legend(); ax.grid(alpha=.2)
fig.tight_layout()
fig.savefig(PERSON3_OUTPUT_DIR / "statistical_roc_pr_curves.png", dpi=160, bbox_inches="tight")
plt.show()
fig, axes = plt.subplots(2, 2, figsize=(11, 9))
for row, family in enumerate(selected_models):
    for col, split in enumerate(["validation", "test"]):
        ConfusionMatrixDisplay.from_predictions(split_data[split][1], model_predictions[(family, split)][1],
            display_labels=["No podium", "Podium"], colorbar=False, ax=axes[row, col])
        axes[row, col].set_title(f"{family}, {split}, threshold={thresholds[family]:.3f}")
fig.tight_layout()
fig.savefig(PERSON3_OUTPUT_DIR / "statistical_confusion_matrices.png", dpi=160, bbox_inches="tight")
plt.show()


comparison_lines = []
for family in selected_models:
    rows = model_comparison.loc[model_comparison["model"].eq(family)].set_index("split")
    comparison_lines.append(f"**{family}:** AP train/validation/test = " + "/".join(f"{rows.loc[s, 'PR_AUC_AP']:.3f}" for s in ["train", "validation", "test"]) +
        f"; test ROC-AUC {rows.loc['test', 'ROC_AUC']:.3f}, F1 {rows.loc['test', 'F1']:.3f}, precision {rows.loc['test', 'precision']:.3f}, recall {rows.loc['test', 'recall']:.3f}. " +
        f"Threshold {thresholds[family]:.3f} was selected on validation only.")
model_interpretation = "\n\n".join(comparison_lines)
display(Markdown(model_interpretation))
for filename, frame in [("split_summary.csv", split_summary), ("tuning_results.csv", tuning_results),
                        ("selected_models.csv", selection_results), ("model_comparison.csv", model_comparison)]:
    frame.to_csv(PERSON3_OUTPUT_DIR / filename, index=False)
(PERSON3_OUTPUT_DIR / "statistical_interpretation.md").write_text(model_interpretation, encoding="utf-8")
(PERSON3_OUTPUT_DIR / "model_contract.json").write_text(json.dumps({"features": FEATURES,
    "target": "podium", "train_end": 2019, "validation_years": [2020, 2021],
    "test_years": [2022, 2024], "thresholds": thresholds, "primary_metric": "average_precision",
    "secondary_metric": "ROC_AUC", "sklearn_version": sklearn.__version__}, indent=2), encoding="utf-8")
# Predictions include stable keys so every downstream model can verify identical rows.
for split, mask in split_masks.items():
    predictions = modeling_table.loc[mask, ["raceId", "driverId", "podium"]].copy()
    for family in selected_models:
        predictions[family + " probability"] = model_predictions[(family, split)][0]
        predictions[family + " prediction"] = model_predictions[(family, split)][1]
    predictions.to_csv(PERSON3_OUTPUT_DIR / f"statistical_predictions_{split}.csv", index=False)
for name, frame in tables_clean.items():
    assert pd.util.hash_pandas_object(frame, index=True).sum() == person3_input_fingerprints[name]
assert pd.util.hash_pandas_object(modeling_table, index=True).sum() == person3_model_fingerprint
pd.testing.assert_frame_equal(selection_results, frozen_selection)
print("Person 3 complete. P1/P2 inputs preserved; all exports:", PERSON3_OUTPUT_DIR)
