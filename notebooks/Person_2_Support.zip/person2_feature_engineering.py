# Run after the completed Person 1 section, with tables_clean, pd, np, plt, display, Markdown and os available.
# Notebook cell 55
import re
import unicodedata
import json
from pathlib import Path

OUTPUT_DIR = Path(os.environ.get("F1_PERSON2_OUTPUT_DIR", "/kaggle/working/outputs"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
# Fingerprint the completed Person 1 tables before feature engineering.
person1_fingerprints = {name: pd.util.hash_pandas_object(frame, index=True).sum()
                        for name, frame in tables_clean.items()}


# Notebook cell 57
ALLOWED_FEATURES = [
    "year", "circuitId", "grid_position", "qualifying_position", "is_home_race",
    "driver_prior_starts", "driver_prior_podium_rate", "driver_prior_mean_finish",
    "constructor_prior_podium_rate", "constructor_prior_mean_points",
    "driver_circuit_prior_starts", "driver_circuit_prior_podium_rate",
    "driver_prior_standing_points", "driver_prior_standing_position",
    "constructor_prior_standing_points", "constructor_prior_standing_position",
]


# Notebook cell 59
def normalize_country_text(value):
    if pd.isna(value):
        return None
    value = unicodedata.normalize("NFKD", str(value))
    value = "".join(char for char in value if not unicodedata.combining(char))
    return re.sub(r"\s+", " ", value.casefold().strip()).strip(" .") or None

NATIONALITY_TO_COUNTRY = {
    "american": "united states", "argentine": "argentina", "argentinian": "argentina",
    "australian": "australia", "austrian": "austria", "belgian": "belgium",
    "brazilian": "brazil", "british": "united kingdom", "canadian": "canada",
    "chilean": "chile", "chinese": "china", "colombian": "colombia", "czech": "czech republic",
    "danish": "denmark", "dutch": "netherlands", "finnish": "finland", "french": "france",
    "german": "germany", "hungarian": "hungary", "indian": "india", "indonesian": "indonesia",
    "irish": "ireland", "italian": "italy", "japanese": "japan", "liechtensteiner": "liechtenstein",
    "malaysian": "malaysia", "mexican": "mexico", "monegasque": "monaco", "monacan": "monaco",
    "new zealander": "new zealand", "polish": "poland", "portuguese": "portugal",
    "russian": "russia", "south african": "south africa", "spanish": "spain",
    "swedish": "sweden", "swiss": "switzerland", "thai": "thailand", "uruguayan": "uruguay",
    "venezuelan": "venezuela", "american-italian": None, "argentine-italian": None,
    "east german": None, "rhodesian": None,
}
CIRCUIT_COUNTRY_TO_COUNTRY = {
    value: value for value in ["argentina", "australia", "austria", "azerbaijan", "bahrain",
    "belgium", "brazil", "canada", "china", "france", "germany", "hungary", "india", "italy",
    "japan", "malaysia", "mexico", "monaco", "morocco", "netherlands", "portugal", "qatar",
    "russia", "saudi arabia", "singapore", "south africa", "spain", "sweden", "switzerland",
    "turkey", "united states"]
}
CIRCUIT_COUNTRY_TO_COUNTRY.update({"uk": "united kingdom", "usa": "united states",
                                  "uae": "united arab emirates", "korea": "south korea"})

NON_START_STATUSES = {"Did not qualify", "Did not prequalify", "Withdrew", "Excluded",
                      "107% Rule", "Injured", "Injury", "Safety concerns"}

def classify_start_status(frame):
    laps = pd.to_numeric(frame["laps"], errors="coerce")
    grid = pd.to_numeric(frame["grid"], errors="coerce")
    explicit_nonstart = frame["status"].isin(NON_START_STATUSES)
    label = pd.Series("unknown", index=frame.index, dtype="string")
    label.loc[explicit_nonstart & laps.eq(0)] = "nonstarter"
    label.loc[~explicit_nonstart & frame["status"].notna() & (laps.gt(0) | grid.gt(0))] = "started"
    return label

def prior_history(entries, keys, prefix):
    history = entries.copy()
    started = history["start_class"].eq("started")
    history["_starts"] = started.astype(int)
    history["_podiums"] = history["podium"].where(started, 0)
    history["_finish"] = history["finish_position"].where(started)
    history["_points"] = history["points"].where(started)
    grouped = history.groupby(keys + ["race_order"], as_index=False, dropna=False).agg(
        starts=("_starts", "sum"), podiums=("_podiums", "sum"),
        finish_sum=("_finish", "sum"), finish_count=("_finish", "count"),
        points=("_points", lambda s: s.sum(min_count=1)))
    grouped = grouped.sort_values(keys + ["race_order"], kind="stable")
    grouped["started_race"] = grouped["starts"].gt(0).astype(int)
    # Unknown points on a started race are not silently treated as zero in its mean.
    grouped["points_known"] = (grouped["started_race"].eq(1) & grouped["points"].notna()).astype(int)
    grouped["points_filled"] = grouped["points"].fillna(0)
    by_entity = grouped.groupby(keys, sort=False, dropna=False)
    prior_starts = by_entity["starts"].cumsum() - grouped["starts"]
    grouped[f"{prefix}_prior_starts"] = prior_starts
    prior_podiums = by_entity["podiums"].cumsum() - grouped["podiums"]
    prior_finish_sum = by_entity["finish_sum"].cumsum() - grouped["finish_sum"]
    prior_finish_count = by_entity["finish_count"].cumsum() - grouped["finish_count"]
    prior_points = by_entity["points_filled"].cumsum() - grouped["points_filled"]
    prior_points_races = by_entity["points_known"].cumsum() - grouped["points_known"]
    grouped[f"{prefix}_podium_rate"] = prior_podiums / prior_starts.replace(0, np.nan)
    grouped[f"{prefix}_mean_finish"] = prior_finish_sum / prior_finish_count.replace(0, np.nan)
    grouped[f"{prefix}_mean_points"] = prior_points / prior_points_races.replace(0, np.nan)
    return grouped

def lag_standings(frame, entity, prefix, race_metadata):
    source = frame.merge(race_metadata, on="raceId", how="left", validate="many_to_one").copy()
    if source.duplicated(["raceId", entity]).any():
        raise ValueError(f"Duplicate standings keys for {entity}")
    for col in ["points", "position"]:
        source[col] = pd.to_numeric(source[col], errors="coerce")
    source = source.rename(columns={"race_order": "standing_source_race_order"})
    targets = entries[["raceId", "year", "race_order", entity]].drop_duplicates().copy()
    joined = pd.merge_asof(
        targets.sort_values("race_order"),
        source[["year", entity, "standing_source_race_order", "points", "position"]].sort_values("standing_source_race_order"),
        left_on="race_order", right_on="standing_source_race_order", by=["year", entity],
        direction="backward", allow_exact_matches=False)
    no_prior_record = joined["standing_source_race_order"].isna()
    joined[f"{prefix}_prior_standing_points"] = joined["points"].where(~no_prior_record, 0)
    joined[f"{prefix}_prior_standing_position"] = joined["position"]
    assert (joined.loc[~no_prior_record, "standing_source_race_order"] < joined.loc[~no_prior_record, "race_order"]).all()
    return joined[["raceId", entity, f"{prefix}_prior_standing_points", f"{prefix}_prior_standing_position"]]


# Notebook cell 61
results = tables_clean["results"].copy()
races = tables_clean["races"].copy()
drivers = tables_clean["drivers"].copy()
constructors = tables_clean["constructors"].copy()
circuits = tables_clean["circuits"].copy()
qualifying = tables_clean["qualifying"].copy()

for frame, keys, label in [
    (results, ["raceId", "driverId"], "results"), (races, ["raceId"], "races"),
    (drivers, ["driverId"], "drivers"), (constructors, ["constructorId"], "constructors"),
    (circuits, ["circuitId"], "circuits"), (qualifying, ["raceId", "driverId"], "qualifying"),
]:
    if frame.duplicated(keys).any():
        raise ValueError(f"{label} contains duplicate keys {keys}; resolve them before feature engineering")

races["date"] = pd.to_datetime(races["date"], errors="coerce")
if races["date"].isna().any():
    raise ValueError("The races table contains missing or invalid dates")
race_order = races[["raceId", "date"]].sort_values(["date", "raceId"], kind="stable").copy()
race_order["race_order"] = np.arange(len(race_order))
races = races.merge(race_order[["raceId", "race_order"]], on="raceId", validate="one_to_one")

for column in ["grid", "positionOrder", "points"]:
    results[column] = pd.to_numeric(results[column], errors="coerce")
results["podium"] = results["positionOrder"].le(3).astype("int8")
results["finish_position"] = results["positionOrder"]
entries = results.merge(races[["raceId", "circuitId", "year", "date", "race_order"]], on="raceId", how="left", validate="many_to_one")
if entries["race_order"].isna().any():
    raise ValueError("Some result race IDs do not exist in the races table")
entries = entries.merge(drivers[["driverId", "nationality"]], on="driverId", how="left", validate="many_to_one")
entries = entries.merge(constructors[["constructorId"]], on="constructorId", how="left", validate="many_to_one")
entries = entries.merge(circuits[["circuitId", "country"]], on="circuitId", how="left", validate="many_to_one")
quali = qualifying[["raceId", "driverId", "position"]].rename(columns={"position": "qualifying_position"})
quali["qualifying_position"] = pd.to_numeric(quali["qualifying_position"], errors="coerce")
entries = entries.merge(quali, on=["raceId", "driverId"], how="left", validate="one_to_one")

entries = entries.merge(tables_clean["status"][["statusId", "status"]], on="statusId", how="left", validate="many_to_one")
assert entries["status"].notna().all(), "Missing status labels must be resolved before start auditing"
entries["start_class"] = classify_start_status(entries)
start_audit = entries.groupby(["status", "start_class"], observed=True).size().rename("rows").reset_index()
display(start_audit)
display(entries["start_class"].value_counts(dropna=False).rename("rows").to_frame())
start_audit.to_csv(OUTPUT_DIR / "start_status_audit.csv", index=False)
# Retain a separate evidence label; none of these post-race audit fields is a predictor.
entries["grid_raw"] = entries["grid"]
entries["grid"] = entries["grid"].where(entries["grid"].gt(0))


# Notebook cell 63
def mapping_audit(series, mapping, source_type):
    audit = series.value_counts(dropna=False).rename_axis("source_value").reset_index(name="source_rows")
    audit["normalized"] = audit["source_value"].map(normalize_country_text)
    audit["canonical_country"] = audit["normalized"].map(mapping)
    audit["resolution"] = audit["normalized"].map(
        lambda value: "mapped" if mapping.get(value) is not None else
                      "explicitly unknown" if value in mapping else "unmapped")
    audit["source_type"] = source_type
    return audit

country_mapping_audit = pd.concat([
    mapping_audit(drivers["nationality"], NATIONALITY_TO_COUNTRY, "nationality"),
    mapping_audit(circuits["country"], CIRCUIT_COUNTRY_TO_COUNTRY, "circuit country")], ignore_index=True)
display(country_mapping_audit)
country_mapping_audit.to_csv(OUTPUT_DIR / "country_mapping_audit.csv", index=False)
assert not country_mapping_audit["resolution"].eq("unmapped").any(), "Audit and resolve new source values explicitly"
driver_country = entries["nationality"].map(normalize_country_text).map(NATIONALITY_TO_COUNTRY)
circuit_country = entries["country"].map(normalize_country_text).map(CIRCUIT_COUNTRY_TO_COUNTRY)
known_country = driver_country.notna() & circuit_country.notna()
entries["is_home_race"] = pd.Series(pd.NA, index=entries.index, dtype="Int8")
entries.loc[known_country, "is_home_race"] = driver_country[known_country].eq(circuit_country[known_country]).astype("int8")
# Regression checks for the previously misclassified source pairs.
for nationality, country in [("Indian", "India"), ("Malaysian", "Malaysia"), ("Hungarian", "Hungary")]:
    example = entries.loc[entries["nationality"].eq(nationality) & entries["country"].eq(country)]
    assert not example.empty and example["is_home_race"].eq(1).all()
    print(f"Verified {nationality} at {country}: {len(example)} home entries")
assert entries.loc[~known_country, "is_home_race"].isna().all()


# Notebook cell 65
driver_hist = prior_history(entries, ["driverId"], "driver")
entries = entries.merge(driver_hist[["driverId", "race_order", "driver_prior_starts", "driver_podium_rate", "driver_mean_finish"]].rename(columns={"driver_podium_rate": "driver_prior_podium_rate", "driver_mean_finish": "driver_prior_mean_finish"}), on=["driverId", "race_order"], validate="one_to_one")
constructor_hist = prior_history(entries, ["constructorId"], "constructor")
entries = entries.merge(constructor_hist[["constructorId", "race_order", "constructor_podium_rate", "constructor_mean_points"]].rename(columns={"constructor_podium_rate": "constructor_prior_podium_rate", "constructor_mean_points": "constructor_prior_mean_points"}), on=["constructorId", "race_order"], validate="many_to_one")
circuit_hist = prior_history(entries, ["driverId", "circuitId"], "driver_circuit")
entries = entries.merge(circuit_hist[["driverId", "circuitId", "race_order", "driver_circuit_prior_starts", "driver_circuit_podium_rate"]].rename(columns={"driver_circuit_podium_rate": "driver_circuit_prior_podium_rate"}), on=["driverId", "circuitId", "race_order"], validate="one_to_one")


# Notebook cell 67
for table_name, entity, prefix in [("driver_standings", "driverId", "driver"), ("constructor_standings", "constructorId", "constructor")]:
    standing_features = lag_standings(tables_clean[table_name], entity, prefix, races[["raceId", "year", "race_order"]])
    if standing_features.duplicated(["raceId", entity]).any():
        raise ValueError(f"{table_name} contains duplicate (raceId, {entity}) keys")
    entries = entries.merge(standing_features, on=["raceId", entity], how="left", validate="one_to_one" if entity == "driverId" else "many_to_one")

opening_races = races.loc[races["round"].eq(1), "raceId"]
opening_entries = entries.loc[entries["raceId"].isin(opening_races)]
for prefix in ["driver", "constructor"]:
    assert opening_entries[f"{prefix}_prior_standing_points"].eq(0).all()
    assert opening_entries[f"{prefix}_prior_standing_position"].isna().all()
print("Season-openers verified: zero prior championship points, unknown championship positions.")


# Notebook cell 69
modeling_table = entries[[
    "raceId", "driverId", "constructorId", "year", "circuitId", "date", "country", "nationality",
    "grid_raw", "start_class",
    "grid", "qualifying_position", "is_home_race", "driver_prior_starts", "driver_prior_podium_rate",
    "driver_prior_mean_finish", "constructor_prior_podium_rate", "constructor_prior_mean_points",
    "driver_circuit_prior_starts", "driver_circuit_prior_podium_rate", "driver_prior_standing_points",
    "driver_prior_standing_position", "constructor_prior_standing_points",
    "constructor_prior_standing_position", "podium",
]].rename(columns={"date": "race_date", "country": "circuit_country", "nationality": "driver_nationality", "grid": "grid_position"})
modeling_table = modeling_table.sort_values(["race_date", "raceId", "driverId"]).reset_index(drop=True)
if modeling_table.duplicated(["raceId", "driverId"]).any():
    raise ValueError("Modeling table is not unique at (raceId, driverId)")
assert modeling_table["podium"].isin([0, 1]).all()
assert set(ALLOWED_FEATURES).issubset(modeling_table.columns)
print(f"Modeling rows: {len(modeling_table):,}")
print("Podium prevalence:", modeling_table["podium"].mean())
print("Allowed features:", ALLOWED_FEATURES)
modeling_table.head()
assert len(modeling_table) == len(tables_clean["results"])
assert not modeling_table["grid_position"].eq(0).any()
assert not set(ALLOWED_FEATURES).intersection({"podium", "status", "statusId", "laps", "start_class", "grid_raw"})
for name, frame in tables_clean.items():
    assert pd.util.hash_pandas_object(frame, index=True).sum() == person1_fingerprints[name], name
feature_evidence = modeling_table.loc[modeling_table["year"].le(2019)].copy()
print("Feature evidence restricted to training years through 2019; rows:", len(feature_evidence))


# Notebook cell 71
from pathlib import Path

fig, axes = plt.subplots(1, 2, figsize=(13, 5))
grid_rates = feature_evidence.dropna(subset=["grid_position"]).groupby("grid_position", observed=True)["podium"].agg(["mean", "count"]).query("count >= 20")
axes[0].plot(grid_rates.index, grid_rates["mean"], marker="o")
axes[0].invert_xaxis()
axes[0].set(title="Training: podium rate by positive starting grid", xlabel="Grid position", ylabel="Podium rate")
axes[0].grid(axis="y", alpha=0.25)
form_data = feature_evidence.dropna(subset=["driver_prior_podium_rate"]).copy()
if not form_data.empty:
    form_data["prior_form_decile"] = pd.qcut(form_data["driver_prior_podium_rate"].rank(method="first"), 10, labels=False, duplicates="drop")
    form_rates = form_data.groupby("prior_form_decile", observed=True)["podium"].mean()
    axes[1].plot(form_rates.index + 1, form_rates.values, marker="o")
axes[1].set(title="Training: podium rate by prior driver form", xlabel="Prior podium-rate decile", ylabel="Podium rate")
axes[1].grid(axis="y", alpha=0.25)
fig.tight_layout()

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
fig.savefig(OUTPUT_DIR / "feature_justification.png", dpi=160, bbox_inches="tight")
plt.show()

# Notebook cell 73
correlation_features = [
    "year", "grid_position", "qualifying_position", "is_home_race",
    "driver_prior_starts", "driver_prior_podium_rate", "driver_prior_mean_finish",
    "constructor_prior_podium_rate", "constructor_prior_mean_points",
    "driver_circuit_prior_starts", "driver_circuit_prior_podium_rate",
    "driver_prior_standing_points", "driver_prior_standing_position",
    "constructor_prior_standing_points", "constructor_prior_standing_position",
]
feature_correlations = feature_evidence[correlation_features + ["podium"]].corr(numeric_only=True)["podium"].drop("podium").dropna().sort_values()
display(feature_correlations.rename("correlation_with_podium").to_frame())
fig, ax = plt.subplots(figsize=(9, 6))
feature_correlations.plot(kind="barh", ax=ax, color=["#c44e52" if value < 0 else "#4c72b0" for value in feature_correlations])
ax.axvline(0, color="black", linewidth=0.8)
ax.set(title="Training-only numeric feature correlation with podium", xlabel="Pearson correlation", ylabel="Allowed feature")
fig.tight_layout()
fig.savefig(OUTPUT_DIR / "feature_correlations.png", dpi=160, bbox_inches="tight")
plt.show()

# Notebook cell 75
q2_population_audit = pd.DataFrame([
    {"stage": "All modeling entrants", "rows": len(modeling_table)},
    {"stage": "Inferred starters", "rows": int(modeling_table["start_class"].eq("started").sum())},
    {"stage": "Starters with positive grid", "rows": int((modeling_table["start_class"].eq("started") & modeling_table["grid_position"].gt(0)).sum())},
    {"stage": "Starters, positive grid and known home status", "rows": int((modeling_table["start_class"].eq("started") & modeling_table["grid_position"].gt(0) & modeling_table["is_home_race"].notna()).sum())},
])
display(q2_population_audit)
q2 = modeling_table.loc[modeling_table["start_class"].eq("started") & modeling_table["grid_position"].gt(0),
                        ["grid_position", "is_home_race", "podium"]].dropna().copy()
q2 = q2.loc[q2["is_home_race"].isin([0, 1])]
if q2.empty:
    raise ValueError("No eligible starters for Q2")
exact = q2.groupby(["grid_position", "is_home_race"], observed=True).agg(
    starts=("podium", "size"), podiums=("podium", "sum"), rate=("podium", "mean")).reset_index()
rate_wide = exact.pivot(index="grid_position", columns="is_home_race", values="rate")
starts_wide = exact.pivot(index="grid_position", columns="is_home_race", values="starts")
common_grids = rate_wide.dropna(subset=[0, 1]).index
if len(common_grids) == 0:
    raise ValueError("No common exact-grid support")
rate_wide, starts_wide = rate_wide.loc[common_grids], starts_wide.loc[common_grids]
weights = starts_wide.sum(axis=1) / starts_wide.to_numpy().sum()
assert np.isclose(weights.sum(), 1)
q2_summary = {
    "known_home_status_starts": len(q2),
    "common_grid_support_starts": int(starts_wide.to_numpy().sum()),
    "common_grid_support_fraction": float(starts_wide.to_numpy().sum() / len(q2)),
    "grid_adjusted_away_podium_rate": float((weights * rate_wide[0]).sum()),
    "grid_adjusted_home_podium_rate": float((weights * rate_wide[1]).sum()),
}
q2_summary["grid_adjusted_rate_difference"] = q2_summary["grid_adjusted_home_podium_rate"] - q2_summary["grid_adjusted_away_podium_rate"]
q2["grid_band"] = pd.cut(q2["grid_position"], [0, 3, 10, 20, np.inf], labels=["1-3", "4-10", "11-20", "21+"])
q2_grid_bands = q2.groupby(["grid_band", "is_home_race"], observed=True).agg(
    starts=("podium", "size"), podiums=("podium", "sum"), podium_rate=("podium", "mean")).reset_index()
fig, axes = plt.subplots(1, 2, figsize=(13, 5))
for flag, label in [(0, "Away"), (1, "Home")]:
    group = q2_grid_bands.loc[q2_grid_bands["is_home_race"].eq(flag)]
    axes[0].plot(group["grid_band"].astype(str), group["podium_rate"], marker="o", label=label)
axes[0].set(xlabel="Positive grid position band", ylabel="Observed podium rate", title="Q2: eligible starters by grid band")
axes[0].legend()
axes[1].bar(["Away", "Home"], [q2_summary["grid_adjusted_away_podium_rate"], q2_summary["grid_adjusted_home_podium_rate"]])
axes[1].set(ylabel="Standardized podium rate", title="Q2: same exact-grid distribution")
for ax in axes:
    ax.set_ylim(bottom=0)
    ax.grid(axis="y", alpha=.25)
fig.tight_layout()
fig.savefig(OUTPUT_DIR / "q2_home_podium_by_grid.png", dpi=160, bbox_inches="tight")
plt.show()
display(pd.DataFrame([q2_summary]))
display(exact)
display(q2_grid_bands)
difference = 100 * q2_summary["grid_adjusted_rate_difference"]
direction = "higher" if difference > 0 else "lower" if difference < 0 else "the same"
q2_interpretation = (
    f"Among {len(q2):,} eligible starters, exact-grid standardization gives a home podium rate of "
    f"{q2_summary['grid_adjusted_home_podium_rate']:.2%} and an away rate of "
    f"{q2_summary['grid_adjusted_away_podium_rate']:.2%}. The home rate is {abs(difference):.2f} percentage points "
    f"{direction}. Common-grid support covers {q2_summary['common_grid_support_fraction']:.1%} of eligible starters. "
    "This is a descriptive association, not a causal effect or a significance test. "
    "It is conditional on the documented starter, positive-grid and country-mapping policy; "
    "driver strength, constructor, era and repeated driver observations remain uncontrolled.")
display(Markdown(q2_interpretation))
pd.DataFrame([q2_summary]).to_csv(OUTPUT_DIR / "q2_summary.csv", index=False)
q2_population_audit.to_csv(OUTPUT_DIR / "q2_population_audit.csv", index=False)
exact.to_csv(OUTPUT_DIR / "q2_exact_grid_rates.csv", index=False)
weights.rename("pooled_weight").to_csv(OUTPUT_DIR / "q2_exact_grid_weights.csv")
q2_grid_bands.to_csv(OUTPUT_DIR / "q2_grid_band_rates.csv", index=False)
modeling_table.to_csv(OUTPUT_DIR / "modeling_table.csv", index=False)
(OUTPUT_DIR / "q2_interpretation.md").write_text(q2_interpretation, encoding="utf-8")
(OUTPUT_DIR / "allowed_features.json").write_text(json.dumps(ALLOWED_FEATURES, indent=2), encoding="utf-8")
print("Saved Person 2 deliverables:", OUTPUT_DIR)
