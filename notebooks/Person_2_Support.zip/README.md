# Person 2 corrected integration

Source: asser 4f156a0028abc34fdf2a5957a7b09223acd8d742, integrated after main 674fe0f6000a63146482d825b2037075c2f82493.

The combined notebook is notebooks/part1completed.ipynb. All 53 Person 1 source cells were preserved. Person 2 appears once after that section. Its generated outputs are in this archive. No changes to sama or zeina are required to perform this merge.

Run All in Kaggle with the F1 dataset attached. For local execution, set F1_DATA_DIR to the 14 CSV directory, F1_OUTPUT_DIR to a new Person 1 output directory (the P1 plot manifest expects exactly ten plots), and F1_PERSON2_OUTPUT_DIR to a separate Person 2 output directory. The Python export is the Person 2 section only and requires Person 1's notebook namespace.

Modeling grain and contract:
- 26,668 result-entrant rows, unique by raceId/driverId, retained across all models. A listed entrant may not have started. The model estimand is podium per listed entrant.
- Use ONLY allowed_features.json as predictors; the target is podium. Additional raw-grid and start_class columns are retrospective audit metadata. Never select all numeric columns blindly.
- Starter-based historical features and Q2 use the documented inferred-start policy, not all entrants. Missing/ambiguous starts are excluded from historical outcomes and denominators; the entrant table retains them. Zero-lap positive-grid retirements are inferred starts. Contradictory positive-lap/non-start labels stay unknown.
- Raw zero grids are missing model grid positions, never automatically labeled pit lane.
- Dual and historical ambiguous nationalities are explicitly unknown; all distinct mappings are audited.
- Standings are the latest strictly earlier record within year/entity; before any same-season record points are zero and rank unknown. Missing later source points stay missing.
- Histories are lifetime prior form; constructor points average earlier races with starters and known points. Constructor teammates are aggregated before historical accumulation.
- Training <=2019, validation 2020-2021, test 2022-2024. Feature evidence uses training only. Q2 is full-history descriptive analysis and must not be used for predictive feature tuning.

Validation:
- All 44 code cells executed top to bottom in a fresh Python process with IPython. Jupyter socket creation was unavailable in this execution environment; no claim is made of an nbclient kernel run.
- P1 sources preserved and P1 tables fingerprinted unchanged during P2.
- Indian/Malaysian/Hungarian home-entry regression checks passed.
- All driver prior_starts verified against cumulative earlier inferred starts.
- Perturbing a race's outcomes/start eligibility did not change that race's own prior-history features for driver, constructor or driver/circuit groups.
- Opening standings reset to zero points/unknown positions; each source lookup is strictly prior within season.
- CSV rows unique, binary target, no current-status/start metadata in predictors; saved notebook has no stale errors.

Downstream models must regenerate their input from this corrected modeling_table.csv, using identical splits and ALLOWED_FEATURES. Previous feature values and model results should be rerun because the historical-start, country and standings semantics have changed intentionally.

See validation_results.json, country_mapping_audit.csv, start_status_audit.csv, q2_population_audit.csv and feature_dictionary.csv for evidence. Q2 results are observational and have no causal or significance claim.
